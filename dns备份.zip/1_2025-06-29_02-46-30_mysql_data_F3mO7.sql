-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: 1
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dnsmgr_account`
--

DROP TABLE IF EXISTS `dnsmgr_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_account` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `ak` varchar(256) DEFAULT NULL,
  `sk` varchar(256) DEFAULT NULL,
  `ext` varchar(256) DEFAULT NULL,
  `proxy` tinyint(1) NOT NULL DEFAULT '0',
  `remark` varchar(100) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_account`
--

LOCK TABLES `dnsmgr_account` WRITE;
/*!40000 ALTER TABLE `dnsmgr_account` DISABLE KEYS */;
INSERT INTO `dnsmgr_account` VALUES (2,'cloudflare','2403278686@qq.com','05ab76b7ca682d85ae9544284a2449740e057','',0,'','2025-03-09 00:42:36'),(3,'dnspod','AKIDGPLBoGVWKxPeiYBnBLK7g2EG5g4EBxZy','FG6i6IG4g5FE2d2FF2bx52mIgrqfIk4H','',0,'','2025-03-13 06:09:44');
/*!40000 ALTER TABLE `dnsmgr_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_cert_account`
--

DROP TABLE IF EXISTS `dnsmgr_cert_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_cert_account` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `config` text,
  `ext` text,
  `remark` varchar(100) DEFAULT NULL,
  `deploy` tinyint(1) NOT NULL DEFAULT '0',
  `addtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_cert_account`
--

LOCK TABLES `dnsmgr_cert_account` WRITE;
/*!40000 ALTER TABLE `dnsmgr_cert_account` DISABLE KEYS */;
INSERT INTO `dnsmgr_cert_account` VALUES (6,'google','huangjiang10086@gmail.com','{\"email\":\"huangjiang10086@gmail.com\",\"eabMode\":\"manual\",\"kid\":\"3e8c32732ae55a533535061d75e74abd\",\"key\":\"aGKXMbbFbucXpQpqWC2BuC6Dg-B8_T67nDyFtqvbrAU1K3N2buc_17MqctYGXZ1Ag30Zm2PF77xxgio2Qiy5fA\",\"mode\":\"live\",\"proxy\":1,\"proxy_url\":\"https://123.9ts.cc\"}','{\"kid\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/account\\/GwZxTAaFSZ_EyQvFHMJ3Wg\",\"key\":\"-----BEGIN PRIVATE KEY-----\\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC\\/DpxoZUGAnD\\/a\\n9Rbo2x8Jn3CrF5QOi5iXiOKI1S0z9zOtOyNWDHmld0b7bpz3RFMM8M3FfxvK8Wk1\\nQSeC1kYknzSfUpse8gMZ0x03iJdKfmv79w76MiwOU3PWkfcRdggq8LdCQMfSrwjl\\nncLjLryLWUjK6NgzuRPWuUR+6j9H4YnRY0PZzC+YbLzMW9N2Zl4jVq7cNFWgeGy6\\neZAIEe\\/YapgE0A6DB1ZS33Gs68sioRG+4IxL7KoCs+0WcPutXeiXpErcOJnROetb\\nTkMJXRyEysNYfsf6\\/H\\/+oAjkzfY4nMYBHgvOD3o+24ev+Fjs+Dm0vJUzlUEF9PTY\\nuk9Cc5HJAgMBAAECggEAMbDGIyy6pY192h\\/GbpeW8fTC4+zE+Cd8b2UNrhLrp8lS\\namqoHRgvh0aHcptpPbJKe2Ih0ozlmJnDCDPC5\\/d81MeHcyyT5a+B+PR8c9YVqy1I\\nPocaIR5tcOhph1P9U1BEfY6Pyy54Cia2BKpMZrPgG8oD8aovmPw42a7jzrJz9OiS\\n5xUEYxc6V+1t8brOEPKdnyemC9Wb8Nx6CyDRrOX7y3Qeys18nrcDIDpUFmoKJ54N\\nHbdaw9RAxMH9SoVXAT5po3JyI+Am86I6eJ5nId4iFKgXAQp5PnKhWZy3KmuhZH3s\\nu\\/EnObtmMm8BdAklWz+FtYChjzlnie8LaITS86aeUQKBgQD7eOIreXZS4NCnUpcG\\n5E3IvAsM1Cv+GNoxVAOvF7iSM9onchSSo4jX\\/SQreE3VFNqe2zQ+hG2Kwl1XgmGi\\nKzOib6ZL\\/3xNR3nACm7Kr54h\\/uk5R20j07aUAkiRYFV\\/12h\\/GRs1Tu+y3aUEotXx\\nxsvVWhD10vIWk4yTnT9q6ed6XQKBgQDCf0EycqJoaECazCrIGUW8xZxykFnPB4d6\\nxYiBWMRKiDHJL9PeVcKAkbIjTho8QhGIealSpIgraqaLibelOc\\/gRNuIcnTLuQcp\\nqoYM4pSrsOh33JHx4NXpo5uoIdQRB3m8nNt8Q4TjZI8kIVN23j+44ZEJsxuMFK4U\\nAseSf\\/a2XQKBgEuYQj0ZbUVqya6S+E2dEfj29kdr\\/LGM3QKZI+ZdtiFVLw5Oj\\/qo\\n6HktYtMifhtBAptgf+sPOjLNTOwCiMEMRaBd+dq8uawtgV8Gg9mwQ1Qq4gdS\\/m8X\\ntLn3mcMB95HPul0CuhgjW5Ekaffjz3a38Qx438JWIGpC\\/q5dRfQozmoNAoGBAJF1\\nRFgrPWTiGvbqHFC7\\/di43VEcvd3EXsElu\\/ooXdzz0HALMeOEtcsbq2MWBS7tplkv\\ny78\\/x4rY3ydaXprWCq5KMPjxyIGXplC19Dzss41X5\\/PEZO3FXZW3QzFR41y8\\/4Fc\\nuhVMFbVOPnMh7V7nxjZJlAPyDHcN\\/EaA8aqRwvwNAoGBANKxf+suWUrKJUpl0+Hl\\nS8lDLMsl\\/mrAdIRYoQScxm37S1dTt038wkBTHWvunvC8zzq53cb0wbah3VEBWOsK\\nTdUjtncCkwuIartRXR12vIeV92ALZGAvN7miGY2QSlj9Xn7dRB6WCy4r+Xg121DD\\nWd7+IH5k4IC1+fzIT+0krFB1\\n-----END PRIVATE KEY-----\\n\"}','谷歌ssl证书',0,'2025-03-09 01:02:13'),(7,'letsencrypt','2403278686@qq.com','{\"email\":\"2403278686@qq.com\",\"mode\":\"live\",\"proxy\":\"0\"}','{\"kid\":\"https:\\/\\/acme-v02.api.letsencrypt.org\\/acme\\/acct\\/2270180676\",\"key\":\"-----BEGIN PRIVATE KEY-----\\nMIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDJks9b4nW6LLkG\\nWLzVyVLWhIEOLbTCdrmDDepBqE23TzYYeYG6SWaO05TUG9nqY4OCzjligQrrf5qG\\nA3gfDQWaB07oHNFjt5\\/N74Fj6okGYnAzjef1TwzVxrBhJVb9gPbFxbAI6hR4NXt3\\nAWvLAQ99FjuF6CLnTUvhLSLwG0TrOKu6BHYhyjuSxsFT7mDoq3E15qRmEazWU10\\/\\nFbA2TNq8HaznsgxroOtWjw15iIPIu2VowwvcsgmvyZ0uxTpB\\/7XUenK2PzaFxBhz\\nvFxlvTK0FkI9FBf48vutZXq7P57egRYJxFpdh0f\\/G5AG4Inx8d5IkmzE\\/NpOgMxa\\nmqh75TlZAgMBAAECggEBAK2RrNwB9D2LpQbCAlhUMvBkyHvc\\/3kzoionIT\\/IHKNr\\nobkRZ5NxAM6bgdvi35HkfqlzyhX3599A0V30Psr9+4TWJivYJLUouIIrac8PdU36\\nFYNO\\/h1NJFAv9lCwRmejVNqXjy0d4uJfqyCeKKN1FlEvg7GaYfOpq10J8Luvv3iK\\nmwne1Fvp3MQzzi3weayQ9xSeqdUAgK0Az7c40cX2T\\/f4QXxBfzqmGkro0qS6k0YF\\nRUtxbdZvTyb1le5nDCBKNdicR\\/JhLbnvY+sOZyqgP7LvxNi0gO2XmL8K3Ocg27Ok\\nWcr\\/usexNr7y2oIwo2qDoslPx22zEG1okwN5g2zaRwECgYEA+IKSWmpP9OYGj+y5\\n6WJ90hpNBD+WmvGSCCLWvl2Ft4JolQk1zTXs6ffWaJ\\/ZsF3Sdbz8yrff1himlyxE\\nrU9DyjP3JGwDZnM4fg\\/xxYIHAapusEpURFcDaThwqo\\/vE6Ur2icOxv+XEbUaZh01\\n4necrL641zP0\\/nv8OxRTEbDCPpUCgYEAz6YXBlQeoxTnmD7ISKYjlqmxARq\\/fWZ0\\nQ6dr1S6bV9sYMtl2rbLP2tLpk3EH6+AXs2yGMbh3vOOLjpe\\/Eb3dbQeSLsuI98wn\\nKHW1dSuI\\/4WOWTj3mWla5LxcjXTZ7jTnt8mf\\/ge6XNRzAOFqB6wXul8DrdIXCXmQ\\nGzM0wj3mkrUCgYEA58bAQVvOXxb7H9kmPCoEN6UYF9JG4RRVowj7SGlpgZI7gGUq\\nrM6SvFTOwJ32Jqwa0n0FOPzt43zyQySimRHIpBp7cpjbQv5LvieY0yFG76LJwdpR\\nZbvSDpz5V9sOnD\\/8+mZbPfa8K2PBz2OHEkWE9wia1Pw8j+2Lfn6iS2mUgVECgYEA\\npkgpzf6U3iGCaE92UX8BpsfSn8DMsV3XIsoyNu\\/wpAUmNqogOG6ltmUJePGd10yH\\njj4MpEpFUHSjMBfigRGa\\/JGAhYql71GD1gmUuvSW65AG8voEhMxyZhNUxk5ZqkCh\\ngnKqdWG44lealIzuPKCaC7vElXBU1FiNhsqVqCqrtrUCgYAbRs8okVa+UxrooTZE\\nEsusOVCx7+o7NZkOyYPi2k3T8vdIrwfAFc31sAA0e53wopp8kysc+dDhuQQXDPrx\\nxStJsHxagYFKwmQC6ZEI0hrcEzarw5aNVatiW9ZXnp82weQ4ra+J6vZmBEqvdZee\\n0Iu\\/CgBbg53RaOexLScXQ8Dhzg==\\n-----END PRIVATE KEY-----\\n\"}','',0,'2025-03-09 01:02:52'),(8,'tencent','AKIDGPLBoGVWKxPeiYBnBLK7g2EG5g4EBxZy','{\"SecretId\":\"AKIDGPLBoGVWKxPeiYBnBLK7g2EG5g4EBxZy\",\"SecretKey\":\"FG6i6IG4g5FE2d2FF2bx52mIgrqfIk4H\",\"proxy\":\"0\"}',NULL,'',1,'2025-03-10 06:39:22'),(10,'huawei','15YUNTYEOIS8NGS6BR0D','{\"AccessKeyId\":\"15YUNTYEOIS8NGS6BR0D\",\"SecretAccessKey\":\"j5unGwCPd6yo61Ibt9r3SD46izXVJ143JzYAbfo4\",\"proxy\":\"0\"}',NULL,'',1,'2025-03-10 15:05:58'),(11,'zerossl','2403278686@qq.com','{\"email\":\"2403278686@qq.com\",\"eabMode\":\"manual\",\"kid\":\"xonAtad6lR-PSr8NqGsfbA\",\"key\":\"WqANsIrJ5SGmYDmNPPJKrp5O5Ppw98DdFepKrR_I2bOnwSqBN_QQLkUPB9IZuKMVlIGZEQpPPxVdoT0JZfbYWQ\",\"proxy\":\"0\"}','{\"kid\":\"https:\\/\\/acme.zerossl.com\\/v2\\/DV90\\/account\\/xonAtad6lR-PSr8NqGsfbA\",\"key\":\"-----BEGIN PRIVATE KEY-----\\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC8TY1TNUr1S4KX\\n55loo2h4RQQ5mSMVmij3oWRfugIy9bWLbY7on2ZbdkU0EcfhSIsm6eYIo\\/jsh\\/cM\\n0opfWq40CrpXhf0PmQeup5Cx9Iu33iOCMVG8K3sOSSDeIQu4u+ufstEWlUg3GgnO\\njhtcuvbTNUTikIgWw4HSIpgP1nz\\/erLmW7gtpqq7UqVMEOAr1wDprg4Y\\/GO8zBbx\\n1Zo74+mOwiKPjMmVP9BM72MnoZow2WsfRsQ7o686LgsIZfIZTYPcyF+N6uLdsL8v\\nZI9O8oU++zF70Yr9aSnIag3LiLnowzrlGjnDDuBoZpp35ys0sO2f1g9RQEg0NY8z\\n92\\/PJm8jAgMBAAECggEACgt5Bn9JSFyG0uOf410ULZZA63Gn1XcryEnruM+LXnyM\\n+qsVfINESoy8lFJ+fx4HjkPb6YoVtUhrfVud1ghYUp5f4ltbbIGVT1PQ\\/C03Zs+K\\nxV8sJQWMwu5TuoW4wloD77jyPmooOAhDjak2\\/HNcx1eIHS3olI5JVpRR2EZw1I\\/3\\neRRLWep0Y5iW6dC2\\/XocIn7PFtQodCCmQK4m7LvnSgepXt\\/L5yf\\/V6MWT0hzzC+E\\n5aP4AAqnlbc4VbGzFDi5l\\/eCBvsu5Nj7Y8iLl6S0nhOi0fr+S0tHlea5U0mduH8F\\nvEDGLeN01ibn4jRJFMDkgwBX95L1lVN1xq4aeSIewQKBgQD1e1mxHQFCEBSOD+8m\\nMxTN3DJ\\/mz4DulyYK287sveT9b8XZ+u32S\\/Z8qHb5Vt9N2DSPa\\/dpX0r3J3KiWzN\\nR7W2BoLgLMHBoyB2lL+ngWKSafJoMcfHVIOPkJyWzy6YhIQdoEh3xPJJHXfxdRYH\\n9sY8CDO8NHTvSD7O3w\\/8uUVD9QKBgQDEXwQL4fEaUBO6gBz7IRleEMgul0gX7wXf\\n7Ce3XfOnw0Rn0gPeQoN6L\\/JKvyR\\/DSVVIo0dW\\/XrBvNloM0mune+jiLJ42pPgXS7\\nqQBWgfh\\/OTCOS\\/SnqooBPAbuWBv14wU\\/l4cud0FMMOHqimuNMqRNuBWDJ7XhZSaP\\njXGd59mPtwKBgBRfc1cmoBcafIo5ulBCRwS6tJowiRoIGm0qlaWvuapW59AKeN6e\\nMMF2yIYWZ9xhfzCTnAfaFyRPv+yyMQxsWiFMMwplzILEhgoxWCKPs12RW2PYVcsu\\nMWj1yHkfoq9XuBs5VSpTdwQoZO7uF7D7gwIycBC7jcTaCxRiINKJkb0NAoGAU7AS\\nr2W5NPePkNnsf\\/IZN4d7aK+8X8bUABxKyNDXeFW1n3FXiK9cDQTGA6j2Stc1Y9T3\\nwt1gLqulq1geVjT9t04n8VZkBkIrl5ZsuHFnkAC1es9QEuyRJ\\/mHEqimMeJwaCuR\\nxvG3+FqUzTn0oBZHA4BCWsTftJFBH8it9RfMFn0CgYAky4u3jC1k64Wxjh8MRnK1\\n2+3qOZNO\\/GbDqiYb42nuzdvTL+TFckeobw0QFbQH22taCzAfRFnP0puAyYyI35CR\\ngLiL8cGQ\\/u0\\/EDwCKV0dQG\\/KJ0Kd4BdquaTOYG9euFL\\/wJK\\/zIHPcsO35L7MDcH\\/\\nP5VmZWZeIhL944eqMK61pA==\\n-----END PRIVATE KEY-----\\n\"}','',0,'2025-06-05 19:19:56');
/*!40000 ALTER TABLE `dnsmgr_cert_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_cert_cname`
--

DROP TABLE IF EXISTS `dnsmgr_cert_cname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_cert_cname` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(255) NOT NULL,
  `did` int(11) unsigned NOT NULL,
  `rr` varchar(128) NOT NULL,
  `addtime` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_cert_cname`
--

LOCK TABLES `dnsmgr_cert_cname` WRITE;
/*!40000 ALTER TABLE `dnsmgr_cert_cname` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnsmgr_cert_cname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_cert_deploy`
--

DROP TABLE IF EXISTS `dnsmgr_cert_deploy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_cert_deploy` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(11) unsigned NOT NULL,
  `oid` int(11) unsigned NOT NULL,
  `issuetime` datetime DEFAULT NULL,
  `config` text,
  `remark` varchar(100) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  `processid` varchar(32) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `error` varchar(300) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `retry` tinyint(4) NOT NULL DEFAULT '0',
  `retrytime` datetime DEFAULT NULL,
  `islock` tinyint(1) NOT NULL DEFAULT '0',
  `locktime` datetime DEFAULT NULL,
  `issend` tinyint(1) NOT NULL DEFAULT '0',
  `info` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_cert_deploy`
--

LOCK TABLES `dnsmgr_cert_deploy` WRITE;
/*!40000 ALTER TABLE `dnsmgr_cert_deploy` DISABLE KEYS */;
INSERT INTO `dnsmgr_cert_deploy` VALUES (5,10,9,NULL,'{\"product\":\"cdn\",\"domain\":\"cdn.9ts.cc\",\"project_id\":null,\"region_id\":null,\"cert_id\":null}','','2025-05-14 14:40:14','2025-05-14 14:40:17','787d6c399de63b8b9ea148ffce4799ec',1,NULL,1,0,NULL,0,'2025-05-14 14:40:17',0,NULL),(6,10,9,NULL,'{\"product\":\"cdn\",\"domain\":\"bing.9ts.cc\",\"project_id\":null,\"region_id\":null,\"cert_id\":null}','','2025-05-14 14:41:02','2025-05-14 14:41:05','af831f65b5817152676e82a423e15362',1,NULL,1,0,NULL,0,'2025-05-14 14:41:04',0,NULL);
/*!40000 ALTER TABLE `dnsmgr_cert_deploy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_cert_domain`
--

DROP TABLE IF EXISTS `dnsmgr_cert_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_cert_domain` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) unsigned NOT NULL,
  `domain` varchar(255) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `oid` (`oid`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_cert_domain`
--

LOCK TABLES `dnsmgr_cert_domain` WRITE;
/*!40000 ALTER TABLE `dnsmgr_cert_domain` DISABLE KEYS */;
INSERT INTO `dnsmgr_cert_domain` VALUES (9,4,'utdfhuijk.xkcdn.xyz',1),(10,5,'9ts.cc',1),(11,5,'*.9ts.cc',2),(20,9,'9ts.cc',1),(21,9,'*.9ts.cc',2),(22,10,'*.xkcdnx.xyz',1),(23,10,'xkcdnx.xyz',2),(24,11,'1.xkcdnx.xyz',1),(25,12,'*.xkcdnx.xyz',1),(38,15,'*.9ts.cc',1),(39,15,'9ts.cc',2),(40,15,'xkcdnx.xyz',3),(41,15,'*.xkcdnx.xyz',4),(42,16,'*.xkcdnx.xyz',1),(43,16,'*.1.xkcdnx.xyz',2),(44,16,'*.2.xkcdnx.xyz',3),(45,16,'xkcdnx.xyz',4),(46,16,'*.3.xkcdnx.xyz',5),(47,16,'*.4.xkcdnx.xyz',6),(48,16,'*.5.xkcdnx.xyz',7),(49,16,'*.6.xkcdnx.xyz',8),(50,16,'*.7.xkcdnx.xyz',9),(51,16,'*.8.xkcdnx.xyz',10),(52,16,'*.9.xkcdnx.xyz',11),(53,16,'*.10.xkcdnx.xyz',12);
/*!40000 ALTER TABLE `dnsmgr_cert_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_cert_order`
--

DROP TABLE IF EXISTS `dnsmgr_cert_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_cert_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(11) unsigned NOT NULL,
  `keytype` varchar(20) DEFAULT NULL,
  `keysize` varchar(20) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `processid` varchar(32) DEFAULT NULL,
  `issuetime` datetime DEFAULT NULL,
  `expiretime` datetime DEFAULT NULL,
  `issuer` varchar(100) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `error` varchar(300) DEFAULT NULL,
  `isauto` tinyint(1) NOT NULL DEFAULT '0',
  `retry` tinyint(4) NOT NULL DEFAULT '0',
  `retry2` tinyint(4) NOT NULL DEFAULT '0',
  `retrytime` datetime DEFAULT NULL,
  `islock` tinyint(1) NOT NULL DEFAULT '0',
  `locktime` datetime DEFAULT NULL,
  `issend` tinyint(1) NOT NULL DEFAULT '0',
  `info` text,
  `dns` text,
  `fullchain` text,
  `privatekey` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_cert_order`
--

LOCK TABLES `dnsmgr_cert_order` WRITE;
/*!40000 ALTER TABLE `dnsmgr_cert_order` DISABLE KEYS */;
INSERT INTO `dnsmgr_cert_order` VALUES (4,7,'RSA','2048','2025-03-09 01:48:01','2025-03-10 04:31:33','1910dcc7028ae701a53843ac192e63fa','2025-03-09 00:49:56','2025-06-07 00:49:55','R11',4,NULL,0,0,0,NULL,0,'2025-03-09 01:48:21',0,'{\"status\":\"pending\",\"expires\":\"2025-03-15T17:48:06Z\",\"identifiers\":[{\"type\":\"dns\",\"value\":\"utdfhuijk.xkcdn.xyz\"}],\"authorizations\":[\"https:\\/\\/acme-v02.api.letsencrypt.org\\/acme\\/authz\\/2270180676\\/486745085436\"],\"finalize\":\"https:\\/\\/acme-v02.api.letsencrypt.org\\/acme\\/finalize\\/2270180676\\/361525093816\",\"location\":\"https:\\/\\/acme-v02.api.letsencrypt.org\\/acme\\/order\\/2270180676\\/361525093816\",\"challenges\":[{\"domain\":\"utdfhuijk.xkcdn.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/acme-v02.api.letsencrypt.org\\/acme\\/authz\\/2270180676\\/486745085436\",\"challenge_url\":\"https:\\/\\/acme-v02.api.letsencrypt.org\\/acme\\/chall\\/2270180676\\/486745085436\\/TF7Z9w\",\"key\":\"_acme-challenge.utdfhuijk.xkcdn.xyz\",\"value\":\"q2plndDsAd5TrlpZVG7a9SruYPg25I6YRoug0w8uH9A\"}]}','{\"xkcdn.xyz\":[{\"name\":\"_acme-challenge.utdfhuijk\",\"type\":\"TXT\",\"value\":\"q2plndDsAd5TrlpZVG7a9SruYPg25I6YRoug0w8uH9A\"}]}','-----BEGIN CERTIFICATE-----\nMIIE9jCCA96gAwIBAgISA+UhTS1OHnkZ/2tofDcyJzfYMA0GCSqGSIb3DQEBCwUA\nMDMxCzAJBgNVBAYTAlVTMRYwFAYDVQQKEw1MZXQncyBFbmNyeXB0MQwwCgYDVQQD\nEwNSMTEwHhcNMjUwMzA4MTY0OTU2WhcNMjUwNjA2MTY0OTU1WjAeMRwwGgYDVQQD\nExN1dGRmaHVpamsueGtjZG4ueHl6MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB\nCgKCAQEAtH0pJZF+0v3vROyl5WJIvUZ58j4zbdgkZP9u9K608Hswxjnc7O00H3SZ\ncqZ9U9HlWfM/TgMJYve93bqgtJYhW3jJj3MI585oHJVvt/5UIE+aeoR0TN6Xxei0\nzKilzNNYSpqHvjazbXE5nZmVf8yv93QyKBKGM0Pj3AnhiNO3N/kEBHzPe4xS52n0\nAz3aZVBB/T1L9AQ4xMScjRvc9YZYXeiLgSZcO123jynGu/KQ3nuPKJTHkKQ4LU67\nVccPpSc4lhXiEb7kX9L4fJmTorGATIXgPriBjnp84TnxmbYM7VRETPw85x3yubwa\nvhZcL96ZhqTqkUfGwBU1+E2VH0kxZQIDAQABo4ICFzCCAhMwDgYDVR0PAQH/BAQD\nAgWgMB0GA1UdJQQWMBQGCCsGAQUFBwMBBggrBgEFBQcDAjAMBgNVHRMBAf8EAjAA\nMB0GA1UdDgQWBBTecwRzhs2iJ0XKFp3nLJTj81/vTTAfBgNVHSMEGDAWgBTFz0ak\n6vTDwHpslcQtsF6SLybjuTBXBggrBgEFBQcBAQRLMEkwIgYIKwYBBQUHMAGGFmh0\ndHA6Ly9yMTEuby5sZW5jci5vcmcwIwYIKwYBBQUHMAKGF2h0dHA6Ly9yMTEuaS5s\nZW5jci5vcmcvMB4GA1UdEQQXMBWCE3V0ZGZodWlqay54a2Nkbi54eXowEwYDVR0g\nBAwwCjAIBgZngQwBAgEwggEEBgorBgEEAdZ5AgQCBIH1BIHyAPAAdgDPEVbu1S58\nr/OHW9lpLpvpGnFnSrAX7KwB0lt3zsw7CAAAAZV232LwAAAEAwBHMEUCIFSqL+q/\ny2UumHJtD/hAf8ESCTRN4ASVqAlg4yEnaPkwAiEA5+9QOOOkpo3HWIHgrm4SDyEB\nZBlfX2w+xGDbq9XrNawAdgDM+w9qhXEJZf6Vm1PO6bJ8IumFXA2XjbapflTA/kwN\nsAAAAZV232qOAAAEAwBHMEUCIGLpKcX+z12rVlBPHFxagAvGOpl4VwMql9twSmTw\n8Si4AiEAyA+WJnQjFoUJ38oWq+8+s8TZAyaQfec9OC/UCQ9qPNQwDQYJKoZIhvcN\nAQELBQADggEBACJzYFAMsyI/16Mh5Lrys9TWu4PHZPl4tJEVi9tBQYrJbiGEvksV\nSP4kRa6i1dTB9sUaVLUayWLTkW9IJCahJiSbtd0M2JXb6OyH6Ekm0dTsKRwI6hxF\nUuFopK9ghtOqr/P4993/L5aPw+iGKE5eySNgON7JQiYnaRBrj4Ev7Zkv6hn4jH6a\nix8Yj4WC0LKWOkWj73aN5sz/6ffjYDM6NtJWPHoHzQp0dnYv2F32L+qNpKCxmsqp\nE7ANi5hvlZO46BbvWPnI863qpnVdJjL7NtrNsAOOMYltnS+ui2x/1oyLo9inyOjF\nYNrPB5qJEH9jo9crD/3oBBKQug6WSk2//XI=\n-----END CERTIFICATE-----\n\n-----BEGIN CERTIFICATE-----\nMIIFBjCCAu6gAwIBAgIRAIp9PhPWLzDvI4a9KQdrNPgwDQYJKoZIhvcNAQELBQAw\nTzELMAkGA1UEBhMCVVMxKTAnBgNVBAoTIEludGVybmV0IFNlY3VyaXR5IFJlc2Vh\ncmNoIEdyb3VwMRUwEwYDVQQDEwxJU1JHIFJvb3QgWDEwHhcNMjQwMzEzMDAwMDAw\nWhcNMjcwMzEyMjM1OTU5WjAzMQswCQYDVQQGEwJVUzEWMBQGA1UEChMNTGV0J3Mg\nRW5jcnlwdDEMMAoGA1UEAxMDUjExMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIB\nCgKCAQEAuoe8XBsAOcvKCs3UZxD5ATylTqVhyybKUvsVAbe5KPUoHu0nsyQYOWcJ\nDAjs4DqwO3cOvfPlOVRBDE6uQdaZdN5R2+97/1i9qLcT9t4x1fJyyXJqC4N0lZxG\nAGQUmfOx2SLZzaiSqhwmej/+71gFewiVgdtxD4774zEJuwm+UE1fj5F2PVqdnoPy\n6cRms+EGZkNIGIBloDcYmpuEMpexsr3E+BUAnSeI++JjF5ZsmydnS8TbKF5pwnnw\nSVzgJFDhxLyhBax7QG0AtMJBP6dYuC/FXJuluwme8f7rsIU5/agK70XEeOtlKsLP\nXzze41xNG/cLJyuqC0J3U095ah2H2QIDAQABo4H4MIH1MA4GA1UdDwEB/wQEAwIB\nhjAdBgNVHSUEFjAUBggrBgEFBQcDAgYIKwYBBQUHAwEwEgYDVR0TAQH/BAgwBgEB\n/wIBADAdBgNVHQ4EFgQUxc9GpOr0w8B6bJXELbBeki8m47kwHwYDVR0jBBgwFoAU\nebRZ5nu25eQBc4AIiMgaWPbpm24wMgYIKwYBBQUHAQEEJjAkMCIGCCsGAQUFBzAC\nhhZodHRwOi8veDEuaS5sZW5jci5vcmcvMBMGA1UdIAQMMAowCAYGZ4EMAQIBMCcG\nA1UdHwQgMB4wHKAaoBiGFmh0dHA6Ly94MS5jLmxlbmNyLm9yZy8wDQYJKoZIhvcN\nAQELBQADggIBAE7iiV0KAxyQOND1H/lxXPjDj7I3iHpvsCUf7b632IYGjukJhM1y\nv4Hz/MrPU0jtvfZpQtSlET41yBOykh0FX+ou1Nj4ScOt9ZmWnO8m2OG0JAtIIE38\n01S0qcYhyOE2G/93ZCkXufBL713qzXnQv5C/viOykNpKqUgxdKlEC+Hi9i2DcaR1\ne9KUwQUZRhy5j/PEdEglKg3l9dtD4tuTm7kZtB8v32oOjzHTYw+7KdzdZiw/sBtn\nUfhBPORNuay4pJxmY/WrhSMdzFO2q3Gu3MUBcdo27goYKjL9CTF8j/Zz55yctUoV\naneCWs/ajUX+HypkBTA+c8LGDLnWO2NKq0YD/pnARkAnYGPfUDoHR9gVSp/qRx+Z\nWghiDLZsMwhN1zjtSC0uBWiugF3vTNzYIEFfaPG7Ws3jDrAMMYebQ95JQ+HIBD/R\nPBuHRTBpqKlyDnkSHDHYPiNX3adPoPAcgdF3H2/W0rmoswMWgTlLn1Wu0mrks7/q\npdWfS6PJ1jty80r2VKsM/Dj3YIDfbjXKdaFU5C+8bhfJGqU3taKauuz0wHVGT3eo\n6FlWkWYtbt4pgdamlwVeZEW+LM7qZEJEsMNPrfC03APKmZsJgpWCDWOKZvkZcvjV\nuYkQ4omYCTX5ohy+knMjdOmdH9c7SpqEWBDC86fiNex+O0XOMEZSa8DA\n-----END CERTIFICATE-----\n','-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC0fSklkX7S/e9E\n7KXlYki9RnnyPjNt2CRk/270rrTwezDGOdzs7TQfdJlypn1T0eVZ8z9OAwli973d\nuqC0liFbeMmPcwjnzmgclW+3/lQgT5p6hHRM3pfF6LTMqKXM01hKmoe+NrNtcTmd\nmZV/zK/3dDIoEoYzQ+PcCeGI07c3+QQEfM97jFLnafQDPdplUEH9PUv0BDjExJyN\nG9z1hlhd6IuBJlw7XbePKca78pDee48olMeQpDgtTrtVxw+lJziWFeIRvuRf0vh8\nmZOisYBMheA+uIGOenzhOfGZtgztVERM/DznHfK5vBq+Flwv3pmGpOqRR8bAFTX4\nTZUfSTFlAgMBAAECggEBAIiGKCqvvLQSuvty2iYByy3I8pNHc5WCKj1vbdmNkXZa\naNF4kWFyJ7wnca7kuuY9XfRFaDw1VdNTvH3NHqSa706GtkhY5oKZge0lKGWP7sim\nDh7gtCw1L67XUHOCmi+uKhn8e/No4x5EyCUrOId8KBrQ/OOM55A9qU0W+E+MfgnK\ngDQR88+G/056PDh0s1AnE2DvjYSr60GexIw5A2y7w52hymEqGETCc9/aQg9AOged\n7vug4RP88aQsZb3gHIgf8Nen5K6IaxengU6sQDqYfCjNj3B2JP78METm9rANaE1P\n+68kmPS9BClIWmRKxsdEGDQomTdIysm6B1ZpkwfBZt0CgYEA4QP80k3yz4Uhfen9\nfb34Jn71MXZGj8YEZuhoNw+k13JDI9CLWjib1sViQVI01qsJ4Xhco43Y3ervxZhi\nWrXTz6El2YYsVJ7jkVI2OX1DlPorMt8B0mMucF2d7FZuiWL9ABtm7WRPFznzOv95\no2I9NJ6xhlXSwCbIUAtouUlsA2cCgYEAzVeQ3vx+xjxlet8ybi0eQvURETsUk9cV\n0bPbAWbo/rH/RUrBs0JMQdngDROXlCRv909fWRk7dPEKkuMeLwdLjjkYRTNWkSMj\nRs5wOgwEr7n6f/CkH0Ksi0GUflB+aVwe5nWdGPid6Eym+S3692RVx2pHN+zEOiuH\nLLkRSIB70VMCgYBEzHlSu+6PsL7qxs5w0dK7wnmpo+YzM3JJHKowm6HlFdSdcLgK\n3+AWLMe7/SyWrjkZLTn17/rs71Zcbhk0bv/SLg1qkvGe9e3SkvZtYXV2aX8n0LO3\n5gde5+DPUCX/77o3fCleUBs2mMtbsJ06bWEVY6gX0MndYn5Aqxxb+q0B5QKBgQC8\nUB/Vv21r0xulsWcIT2w/L4v1Z18ZrdietfiUspHecdKO813sTVKt2Wd11o/eFgRw\no2PnzBIQzrVJu+uEaYZK6eVuIQS0marSVqPpN/hcR4yJJGD/IiAmnX/Wz27+pLLZ\n2ua1bdsynIlMX3SWyHc6KCckDIhwaFbRFu/Ys6vZbQKBgE6xlrz24nMNsO3qHpe2\nO6rH9fxdoWhus+MMKZ/yPlUDVNnpMA0tuv235Kla5+Eupn+oW1vsC4uaNFEP7JFp\n9UdC7qOWu/HV2OlEJDlkYZP4/XbnudGEAdQvKShmJnNOb9ozaIPu8oB8YarlpljR\nlUn7qC9VZKprNn035F82RIPu\n-----END PRIVATE KEY-----\n'),(5,6,'ECC','256','2025-03-10 06:11:29','2025-06-01 05:30:13','9fde6f18078d502fe9baf3aa0f588406','2025-06-01 04:30:06','2025-08-30 04:30:05','WR1',3,NULL,0,0,0,NULL,0,'2025-06-01 05:30:03',1,'{\"status\":\"ready\",\"expires\":\"2025-06-11T06:20:06.662861954Z\",\"identifiers\":[{\"type\":\"dns\",\"value\":\"9ts.cc\"},{\"type\":\"dns\",\"value\":\"*.9ts.cc\"}],\"notBefore\":\"1970-01-01T00:00:00Z\",\"notAfter\":\"1970-01-01T00:00:00Z\",\"authorizations\":[\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/DoYHYiKhSoTaQLV6Cu6gaA\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/SSzrhifjb4N_iF8V3zMVEw\"],\"finalize\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/order\\/igJTNVCjGrXbQq3cCXoLsw\\/finalize\",\"location\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/order\\/igJTNVCjGrXbQq3cCXoLsw\"}','[]','-----BEGIN CERTIFICATE-----\nMIIEVjCCAz6gAwIBAgIRAOX8jzNZwffLDs3i5AvaCX0wDQYJKoZIhvcNAQELBQAw\nOzELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFUdvb2dsZSBUcnVzdCBTZXJ2aWNlczEM\nMAoGA1UEAxMDV1IxMB4XDTI1MDUzMTIwMzAwNloXDTI1MDgyOTIwMzAwNVowETEP\nMA0GA1UEAxMGOXRzLmNjMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE4DCwOpVP\nyQJr4t9lcd1h8+Oeyff4wIkXSKUhT1PkoikBSoMkQA5FasWIgsFIrmaU9Zeisiao\nBFk37lJxM+I956OCAkgwggJEMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggr\nBgEFBQcDATAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBR2VqWsPAewWWpf0Qwoe5+Q\nYR71ITAfBgNVHSMEGDAWgBRmaUnU3iqckQPPiQ4kuA4wA26ILjBeBggrBgEFBQcB\nAQRSMFAwJwYIKwYBBQUHMAGGG2h0dHA6Ly9vLnBraS5nb29nL3Mvd3IxLzVmdzAl\nBggrBgEFBQcwAoYZaHR0cDovL2kucGtpLmdvb2cvd3IxLmNydDAbBgNVHREEFDAS\nggY5dHMuY2OCCCouOXRzLmNjMBMGA1UdIAQMMAowCAYGZ4EMAQIBMDYGA1UdHwQv\nMC0wK6ApoCeGJWh0dHA6Ly9jLnBraS5nb29nL3dyMS9IYTIxTjlkWjlkRS5jcmww\nggEDBgorBgEEAdZ5AgQCBIH0BIHxAO8AdQAS8U40vVNyTIQGGcOPP3oT+Oe1YoeI\nnG0wBYTr5YYmOgAAAZcoQIfpAAAEAwBGMEQCIAbvkQkxjvxi5ydGIInUOfxEWoHa\nCC922SBZ7MZXkw2LAiAJChOXdNhRuY63TrfQ82gU26gdk1qb7og38qlGV4KqBgB2\nAH1ZHhLheCp7HGFnfF79+NCHXBSgTpWeuQMv2Q6MLnm4AAABlyhAiA4AAAQDAEcw\nRQIgb656SFlmdNxZvtQnObWoCYBQCRQ0nuJ99w0L32pSYUcCIQDT1pl+uFJyNF3j\nl0Pkrno+u2NJFI2M17a4KBee4OXHBzANBgkqhkiG9w0BAQsFAAOCAQEAlEGt6WJK\nVjqTWu0fGsIOIUf84pyE0LxpHBd9WnL78LETfZ3wrdXVEYmEDmsMnl/U9FiXg5fc\n7qt7mBnXKOvj2N4afg6Y2xV9/ykaocijA7G8xWVXIFEfwH143VC5knfPfq62PGh8\nCRDfjxgYTRL6gC6/QeYwIHDK2IA7NZ+FSonH6Bd5kNPExEoGjxfNp4f8yXytX64J\nPE9nEFWZgYGzI5qBojvCkeE1+cBpskbaqTLxeAtmcopHAeS+YgxFQsWOMGz8k8Sm\nL7SOzWLuRZJKaE+mVy8O2yC/dfZJfwN5GA3mxmm5z6y12Dxleckud44dmOwDiWzO\nfxDVioAbE6F55Q==\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIFCzCCAvOgAwIBAgIQf9niwtIEigR0tieibQhopzANBgkqhkiG9w0BAQsFADBH\nMQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExM\nQzEUMBIGA1UEAxMLR1RTIFJvb3QgUjEwHhcNMjMxMjEzMDkwMDAwWhcNMjkwMjIw\nMTQwMDAwWjA7MQswCQYDVQQGEwJVUzEeMBwGA1UEChMVR29vZ2xlIFRydXN0IFNl\ncnZpY2VzMQwwCgYDVQQDEwNXUjEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK\nAoIBAQDPbjYWircr7kaYAx1TcA937qNLoHK+jyMtwkfGj1yN+T3mGo7uMyINyRFI\nuLBizvRpDXICfd7VJg/DbpvPfg7XIM/GkDujggbaOp3/bFa/3OlhlEXkabxPD8kT\nwK1hRHIggdAPK55oamJqj4oiV3lpK+IkM352YyxdvFFpfiMHsf92gfHuuFi1azUV\n76HmSCg5lzHZBx+Vp56uz5i8no2KA+Gwl01Qb5NMSh/4233xkJkVf+OW7e4xgepy\nPVId3yVkpQtwqp7oqLlHyKdaECVgb0Lh1z/njwzwwoNGMyDmS3cEdqFop10VGO/Y\nKHc1rQ6tRuRibuKq+MzvN34PJrMHAgMBAAGjgf4wgfswDgYDVR0PAQH/BAQDAgGG\nMB0GA1UdJQQWMBQGCCsGAQUFBwMBBggrBgEFBQcDAjASBgNVHRMBAf8ECDAGAQH/\nAgEAMB0GA1UdDgQWBBRmaUnU3iqckQPPiQ4kuA4wA26ILjAfBgNVHSMEGDAWgBTk\nrysmcRorSCeFL1JmLO/wiRNxPjA0BggrBgEFBQcBAQQoMCYwJAYIKwYBBQUHMAKG\nGGh0dHA6Ly9pLnBraS5nb29nL3IxLmNydDArBgNVHR8EJDAiMCCgHqAchhpodHRw\nOi8vYy5wa2kuZ29vZy9yL3IxLmNybDATBgNVHSAEDDAKMAgGBmeBDAECATANBgkq\nhkiG9w0BAQsFAAOCAgEATuazCBEgkWAn+VGQTQIY7rjBidUihJfm1t/mTjo7KQR+\n3iDx4o2L06oeF0Q3wpKYpQgI/TeMqUlYMWQmZbWPE0PX8pfsVAE5E5tVOjh34bNA\nJwDPVnsZVJwzN3nw5BGQ7sxRspFzIcM/qbbTpNeXf9II4Wsk2+Tv6FSVFZUL3/0u\nHradbruDWjRQ4IZ7mYqKiEqk08dpOZ+TmBzwykEGy1/IXberb6Ap1SSnn2+RI7t6\nN/fqPCrwwFjp8kg1G6etRATGBaPYCx+GjJMFPX+k97Alvoj3/98SvqdegLPYEPjv\nxUclHpiKLD63NMmVarVQddIL6kOvTe5k0pnxRnR+mndGHIQc77TLbcZFeja56Pyn\nlSqmer578c7CBrPqo1BVmPyWUK+v6sGuzs7Mq7QQaxVs4710cI/MpPp1ovxMVt17\nENKxLk34LpEKAKVmqwnzbHHRjhXNeCC984XDOwLEp0K4MzHl8ZOWJQAakCdVlFC+\nPyA3GP2JX/QLoqWNHGuN9c9vLObDhHVs/L+65De+OdnnjpFGI9xxtsNyRsyaHdFA\nf5z7ulOoXDXkHCCej/Ehs5docReNt16W2xbH/EBuirJrOzFE2rtALxksl1TdEjOf\nIKXOJfUqQeVI5+hA7V+n1+A/n7Npg0S+5ODytWh5XW54ccN1drJnMK54ttozh0c=\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIFYjCCBEqgAwIBAgIQd70NbNs2+RrqIQ/E8FjTDTANBgkqhkiG9w0BAQsFADBX\nMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTEQMA4GA1UE\nCxMHUm9vdCBDQTEbMBkGA1UEAxMSR2xvYmFsU2lnbiBSb290IENBMB4XDTIwMDYx\nOTAwMDA0MloXDTI4MDEyODAwMDA0MlowRzELMAkGA1UEBhMCVVMxIjAgBgNVBAoT\nGUdvb2dsZSBUcnVzdCBTZXJ2aWNlcyBMTEMxFDASBgNVBAMTC0dUUyBSb290IFIx\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAthECix7joXebO9y/lD63\nladAPKH9gvl9MgaCcfb2jH/76Nu8ai6Xl6OMS/kr9rH5zoQdsfnFl97vufKj6bwS\niV6nqlKr+CMny6SxnGPb15l+8Ape62im9MZaRw1NEDPjTrETo8gYbEvs/AmQ351k\nKSUjB6G00j0uYODP0gmHu81I8E3CwnqIiru6z1kZ1q+PsAewnjHxgsHA3y6mbWwZ\nDrXYfiYaRQM9sHmklCitD38m5agI/pboPGiUU+6DOogrFZYJsuB6jC511pzrp1Zk\nj5ZPaK49l8KEj8C8QMALXL32h7M1bKwYUH+E4EzNktMg6TO8UpmvMrUpsyUqtEj5\ncuHKZPfmghCN6J3Cioj6OGaK/GP5Afl4/Xtcd/p2h/rs37EOeZVXtL0m79YB0esW\nCruOC7XFxYpVq9Os6pFLKcwZpDIlTirxZUTQAs6qzkm06p98g7BAe+dDq6dso499\niYH6TKX/1Y7DzkvgtdizjkXPdsDtQCv9Uw+wp9U7DbGKogPeMa3Md+pvez7W35Ei\nEua++tgy/BBjFFFy3l3WFpO9KWgz7zpm7AeKJt8T11dleCfeXkkUAKIAf5qoIbap\nsZWwpbkNFhHax2xIPEDgfg1azVY80ZcFuctL7TlLnMQ/0lUTbiSw1nH69MG6zO0b\n9f6BQdgAmD06yK56mDcYBZUCAwEAAaOCATgwggE0MA4GA1UdDwEB/wQEAwIBhjAP\nBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTkrysmcRorSCeFL1JmLO/wiRNxPjAf\nBgNVHSMEGDAWgBRge2YaRQ2XyolQL30EzTSo//z9SzBgBggrBgEFBQcBAQRUMFIw\nJQYIKwYBBQUHMAGGGWh0dHA6Ly9vY3NwLnBraS5nb29nL2dzcjEwKQYIKwYBBQUH\nMAKGHWh0dHA6Ly9wa2kuZ29vZy9nc3IxL2dzcjEuY3J0MDIGA1UdHwQrMCkwJ6Al\noCOGIWh0dHA6Ly9jcmwucGtpLmdvb2cvZ3NyMS9nc3IxLmNybDA7BgNVHSAENDAy\nMAgGBmeBDAECATAIBgZngQwBAgIwDQYLKwYBBAHWeQIFAwIwDQYLKwYBBAHWeQIF\nAwMwDQYJKoZIhvcNAQELBQADggEBADSkHrEoo9C0dhemMXoh6dFSPsjbdBZBiLg9\nNR3t5P+T4Vxfq7vqfM/b5A3Ri1fyJm9bvhdGaJQ3b2t6yMAYN/olUazsaL+yyEn9\nWprKASOshIArAoyZl+tJaox118fessmXn1hIVw41oeQa1v1vg4Fv74zPl6/AhSrw\n9U5pCZEt4Wi4wStz6dTZ/CLANx8LZh1J7QJVj2fhMtfTJr9w4z30Z209fOU0iOMy\n+qduBmpvvYuR7hZL6Dupszfnw0Skfths18dG9ZKb59UhvmaSGZRVbNQpsg3BZlvi\nd0lIKO2d1xozclOzgjXPYovJJIultzkMu34qQb9Sz/yilrbCgj8=\n-----END CERTIFICATE-----\n','-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIH7aWPtxb6AeEzWRD+X/fN2dvxaZE+gAKz8T3xv+o3FKoAoGCCqGSM49\nAwEHoUQDQgAE4DCwOpVPyQJr4t9lcd1h8+Oeyff4wIkXSKUhT1PkoikBSoMkQA5F\nasWIgsFIrmaU9ZeisiaoBFk37lJxM+I95w==\n-----END EC PRIVATE KEY-----\n'),(9,6,'ECC','256','2025-05-14 14:15:35','2025-05-14 14:20:27','f988cf758c533e7ecf554a934c788246','2025-05-14 13:20:20','2025-08-12 13:20:19','WR1',3,NULL,0,0,0,NULL,0,'2025-05-14 14:20:02',1,'{\"status\":\"pending\",\"expires\":\"2025-06-11T06:07:50.201197402Z\",\"identifiers\":[{\"type\":\"dns\",\"value\":\"9ts.cc\"},{\"type\":\"dns\",\"value\":\"*.9ts.cc\"}],\"notBefore\":\"1970-01-01T00:00:00Z\",\"notAfter\":\"1970-01-01T00:00:00Z\",\"authorizations\":[\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/DoYHYiKhSoTaQLV6Cu6gaA\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/SSzrhifjb4N_iF8V3zMVEw\"],\"finalize\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/order\\/HllW8Xd3erJoHvQRnyDDoA\\/finalize\",\"location\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/order\\/HllW8Xd3erJoHvQRnyDDoA\",\"challenges\":[{\"domain\":\"9ts.cc\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/DoYHYiKhSoTaQLV6Cu6gaA\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/5hQywe49DU24PWJg1b8mcw\",\"key\":\"_acme-challenge.9ts.cc\",\"value\":\"vmfUydqj43FzSq7LQs3-TdnnlEhbVQD39_PFp5oWByA\"},{\"domain\":\"*.9ts.cc\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/SSzrhifjb4N_iF8V3zMVEw\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/z5ZsAU4dqFrgrVpZIjxnlA\",\"key\":\"_acme-challenge.9ts.cc\",\"value\":\"_Lsk-tcy9KIrICrzrw1oHtPFJ0incG354pKq7SmeAUI\"}]}','{\"9ts.cc\":[{\"name\":\"_acme-challenge\",\"type\":\"TXT\",\"value\":\"vmfUydqj43FzSq7LQs3-TdnnlEhbVQD39_PFp5oWByA\"},{\"name\":\"_acme-challenge\",\"type\":\"TXT\",\"value\":\"_Lsk-tcy9KIrICrzrw1oHtPFJ0incG354pKq7SmeAUI\"}]}','-----BEGIN CERTIFICATE-----\nMIIEWDCCA0CgAwIBAgIRALNhKK368a1rEUieatNc6jUwDQYJKoZIhvcNAQELBQAw\nOzELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFUdvb2dsZSBUcnVzdCBTZXJ2aWNlczEM\nMAoGA1UEAxMDV1IxMB4XDTI1MDUxNDA1MjAyMFoXDTI1MDgxMjA1MjAxOVowETEP\nMA0GA1UEAxMGOXRzLmNjMFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEaRb9x/yJ\njmD/OtnDLbQraWHV9BjGFW+aRELJyC2oeLhIkFefZm7br50dAPC9GvrOK2nrzX0J\nsIBYh1d9vV/6+aOCAkowggJGMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUEDDAKBggr\nBgEFBQcDATAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBTDnsxQw2mlIMRAAWYWb6rm\nzEkzZTAfBgNVHSMEGDAWgBRmaUnU3iqckQPPiQ4kuA4wA26ILjBeBggrBgEFBQcB\nAQRSMFAwJwYIKwYBBQUHMAGGG2h0dHA6Ly9vLnBraS5nb29nL3Mvd3IxL3MyRTAl\nBggrBgEFBQcwAoYZaHR0cDovL2kucGtpLmdvb2cvd3IxLmNydDAbBgNVHREEFDAS\nggY5dHMuY2OCCCouOXRzLmNjMBMGA1UdIAQMMAowCAYGZ4EMAQIBMDYGA1UdHwQv\nMC0wK6ApoCeGJWh0dHA6Ly9jLnBraS5nb29nL3dyMS9SNUdhazFnQkd5VS5jcmww\nggEFBgorBgEEAdZ5AgQCBIH2BIHzAPEAdwAN4fIwK9MNwUBiEgnqVS78R3R8sdfp\nMO8OQh60fk6qNAAAAZbNc4NkAAAEAwBIMEYCIQCGSanmmCmJCu/DavRRluK/u/xY\nJZ+mqYcG+KDUw9m9ngIhAL4Gfuc5mjBJJHZpVdp2RK5F1axDp33EjQfQRqgfGDfL\nAHYAEvFONL1TckyEBhnDjz96E/jntWKHiJxtMAWE6+WGJjoAAAGWzXN/bAAABAMA\nRzBFAiEAwzsR0f15LkamvvkYW9lkfm+L0hOpbLB2mbIBWwsRZr4CIFuSh5IYnjYD\nmHYcoTX+F7V4vDdDQpdjAvFj44gu1F8uMA0GCSqGSIb3DQEBCwUAA4IBAQBAIIHh\nZ4FJ79gXluP7XqE52WiKKuds5UOtO4LI8TA70GxTC3pTa+0Zcqt37S7Wn2SMgZIU\niVJsXOS3v4t9isF0fZmO3QCUGqhoeldjmTU1kF5/FYzGOIsedDT2aHuS7LC8bLMe\nQEMeVeYEVSTdp71OVDjMbCwTdU7qBoABmQhgX8J4q4UsplQIGZiS7LHsIkd7rVLa\nRcC8pl8bI+eOpEg0oovPQgtI2HmLQKRQ4lBjWvh0H2jLFjsK5iAbWChBxkI67cEK\nsmz8JcupOp9tifOyBTXJ8o/0K9UFJVuWPUrSWqwWY2svNBHIYPUnXB3uWBXMV4T4\n9HK15TKIxK+0gcbZ\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIFCzCCAvOgAwIBAgIQf9niwtIEigR0tieibQhopzANBgkqhkiG9w0BAQsFADBH\nMQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExM\nQzEUMBIGA1UEAxMLR1RTIFJvb3QgUjEwHhcNMjMxMjEzMDkwMDAwWhcNMjkwMjIw\nMTQwMDAwWjA7MQswCQYDVQQGEwJVUzEeMBwGA1UEChMVR29vZ2xlIFRydXN0IFNl\ncnZpY2VzMQwwCgYDVQQDEwNXUjEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK\nAoIBAQDPbjYWircr7kaYAx1TcA937qNLoHK+jyMtwkfGj1yN+T3mGo7uMyINyRFI\nuLBizvRpDXICfd7VJg/DbpvPfg7XIM/GkDujggbaOp3/bFa/3OlhlEXkabxPD8kT\nwK1hRHIggdAPK55oamJqj4oiV3lpK+IkM352YyxdvFFpfiMHsf92gfHuuFi1azUV\n76HmSCg5lzHZBx+Vp56uz5i8no2KA+Gwl01Qb5NMSh/4233xkJkVf+OW7e4xgepy\nPVId3yVkpQtwqp7oqLlHyKdaECVgb0Lh1z/njwzwwoNGMyDmS3cEdqFop10VGO/Y\nKHc1rQ6tRuRibuKq+MzvN34PJrMHAgMBAAGjgf4wgfswDgYDVR0PAQH/BAQDAgGG\nMB0GA1UdJQQWMBQGCCsGAQUFBwMBBggrBgEFBQcDAjASBgNVHRMBAf8ECDAGAQH/\nAgEAMB0GA1UdDgQWBBRmaUnU3iqckQPPiQ4kuA4wA26ILjAfBgNVHSMEGDAWgBTk\nrysmcRorSCeFL1JmLO/wiRNxPjA0BggrBgEFBQcBAQQoMCYwJAYIKwYBBQUHMAKG\nGGh0dHA6Ly9pLnBraS5nb29nL3IxLmNydDArBgNVHR8EJDAiMCCgHqAchhpodHRw\nOi8vYy5wa2kuZ29vZy9yL3IxLmNybDATBgNVHSAEDDAKMAgGBmeBDAECATANBgkq\nhkiG9w0BAQsFAAOCAgEATuazCBEgkWAn+VGQTQIY7rjBidUihJfm1t/mTjo7KQR+\n3iDx4o2L06oeF0Q3wpKYpQgI/TeMqUlYMWQmZbWPE0PX8pfsVAE5E5tVOjh34bNA\nJwDPVnsZVJwzN3nw5BGQ7sxRspFzIcM/qbbTpNeXf9II4Wsk2+Tv6FSVFZUL3/0u\nHradbruDWjRQ4IZ7mYqKiEqk08dpOZ+TmBzwykEGy1/IXberb6Ap1SSnn2+RI7t6\nN/fqPCrwwFjp8kg1G6etRATGBaPYCx+GjJMFPX+k97Alvoj3/98SvqdegLPYEPjv\nxUclHpiKLD63NMmVarVQddIL6kOvTe5k0pnxRnR+mndGHIQc77TLbcZFeja56Pyn\nlSqmer578c7CBrPqo1BVmPyWUK+v6sGuzs7Mq7QQaxVs4710cI/MpPp1ovxMVt17\nENKxLk34LpEKAKVmqwnzbHHRjhXNeCC984XDOwLEp0K4MzHl8ZOWJQAakCdVlFC+\nPyA3GP2JX/QLoqWNHGuN9c9vLObDhHVs/L+65De+OdnnjpFGI9xxtsNyRsyaHdFA\nf5z7ulOoXDXkHCCej/Ehs5docReNt16W2xbH/EBuirJrOzFE2rtALxksl1TdEjOf\nIKXOJfUqQeVI5+hA7V+n1+A/n7Npg0S+5ODytWh5XW54ccN1drJnMK54ttozh0c=\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIFYjCCBEqgAwIBAgIQd70NbNs2+RrqIQ/E8FjTDTANBgkqhkiG9w0BAQsFADBX\nMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTEQMA4GA1UE\nCxMHUm9vdCBDQTEbMBkGA1UEAxMSR2xvYmFsU2lnbiBSb290IENBMB4XDTIwMDYx\nOTAwMDA0MloXDTI4MDEyODAwMDA0MlowRzELMAkGA1UEBhMCVVMxIjAgBgNVBAoT\nGUdvb2dsZSBUcnVzdCBTZXJ2aWNlcyBMTEMxFDASBgNVBAMTC0dUUyBSb290IFIx\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAthECix7joXebO9y/lD63\nladAPKH9gvl9MgaCcfb2jH/76Nu8ai6Xl6OMS/kr9rH5zoQdsfnFl97vufKj6bwS\niV6nqlKr+CMny6SxnGPb15l+8Ape62im9MZaRw1NEDPjTrETo8gYbEvs/AmQ351k\nKSUjB6G00j0uYODP0gmHu81I8E3CwnqIiru6z1kZ1q+PsAewnjHxgsHA3y6mbWwZ\nDrXYfiYaRQM9sHmklCitD38m5agI/pboPGiUU+6DOogrFZYJsuB6jC511pzrp1Zk\nj5ZPaK49l8KEj8C8QMALXL32h7M1bKwYUH+E4EzNktMg6TO8UpmvMrUpsyUqtEj5\ncuHKZPfmghCN6J3Cioj6OGaK/GP5Afl4/Xtcd/p2h/rs37EOeZVXtL0m79YB0esW\nCruOC7XFxYpVq9Os6pFLKcwZpDIlTirxZUTQAs6qzkm06p98g7BAe+dDq6dso499\niYH6TKX/1Y7DzkvgtdizjkXPdsDtQCv9Uw+wp9U7DbGKogPeMa3Md+pvez7W35Ei\nEua++tgy/BBjFFFy3l3WFpO9KWgz7zpm7AeKJt8T11dleCfeXkkUAKIAf5qoIbap\nsZWwpbkNFhHax2xIPEDgfg1azVY80ZcFuctL7TlLnMQ/0lUTbiSw1nH69MG6zO0b\n9f6BQdgAmD06yK56mDcYBZUCAwEAAaOCATgwggE0MA4GA1UdDwEB/wQEAwIBhjAP\nBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTkrysmcRorSCeFL1JmLO/wiRNxPjAf\nBgNVHSMEGDAWgBRge2YaRQ2XyolQL30EzTSo//z9SzBgBggrBgEFBQcBAQRUMFIw\nJQYIKwYBBQUHMAGGGWh0dHA6Ly9vY3NwLnBraS5nb29nL2dzcjEwKQYIKwYBBQUH\nMAKGHWh0dHA6Ly9wa2kuZ29vZy9nc3IxL2dzcjEuY3J0MDIGA1UdHwQrMCkwJ6Al\noCOGIWh0dHA6Ly9jcmwucGtpLmdvb2cvZ3NyMS9nc3IxLmNybDA7BgNVHSAENDAy\nMAgGBmeBDAECATAIBgZngQwBAgIwDQYLKwYBBAHWeQIFAwIwDQYLKwYBBAHWeQIF\nAwMwDQYJKoZIhvcNAQELBQADggEBADSkHrEoo9C0dhemMXoh6dFSPsjbdBZBiLg9\nNR3t5P+T4Vxfq7vqfM/b5A3Ri1fyJm9bvhdGaJQ3b2t6yMAYN/olUazsaL+yyEn9\nWprKASOshIArAoyZl+tJaox118fessmXn1hIVw41oeQa1v1vg4Fv74zPl6/AhSrw\n9U5pCZEt4Wi4wStz6dTZ/CLANx8LZh1J7QJVj2fhMtfTJr9w4z30Z209fOU0iOMy\n+qduBmpvvYuR7hZL6Dupszfnw0Skfths18dG9ZKb59UhvmaSGZRVbNQpsg3BZlvi\nd0lIKO2d1xozclOzgjXPYovJJIultzkMu34qQb9Sz/yilrbCgj8=\n-----END CERTIFICATE-----\n','-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIGFK///vG8hPfaS6wKi3KHjg5TuUtos0zywFRNJVS/fYoAoGCCqGSM49\nAwEHoUQDQgAEaRb9x/yJjmD/OtnDLbQraWHV9BjGFW+aRELJyC2oeLhIkFefZm7b\nr50dAPC9GvrOK2nrzX0JsIBYh1d9vV/6+Q==\n-----END EC PRIVATE KEY-----\n'),(10,11,'ECC','256','2025-06-05 19:21:14','2025-06-05 19:37:12','49567806579a1414750012d7097769d9','2025-06-05 08:00:00','2025-09-04 07:59:59','ZeroSSL ECC Domain Secure Site CA',3,NULL,0,0,0,NULL,0,'2025-06-05 19:36:44',0,'{\"status\":\"ready\",\"expires\":\"2025-09-03T11:21:28Z\",\"identifiers\":[{\"type\":\"dns\",\"value\":\"*.xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"xkcdnx.xyz\"}],\"authorizations\":[\"https:\\/\\/acme.zerossl.com\\/v2\\/DV90\\/authz\\/l4c_QoAAkj5NqfcuC6ypsQ\",\"https:\\/\\/acme.zerossl.com\\/v2\\/DV90\\/authz\\/0LYim3-B3-oc8RVghY5iZQ\"],\"finalize\":\"https:\\/\\/acme.zerossl.com\\/v2\\/DV90\\/order\\/frjh890yQ5Me1pfbsUdXRA\\/finalize\",\"location\":\"https:\\/\\/acme.zerossl.com\\/v2\\/DV90\\/order\\/frjh890yQ5Me1pfbsUdXRA\"}','[]','-----BEGIN CERTIFICATE-----\nMIIEBjCCA42gAwIBAgIQXDjdPSdlLveQhMqXk6QfgjAKBggqhkjOPQQDAzBLMQsw\nCQYDVQQGEwJBVDEQMA4GA1UEChMHWmVyb1NTTDEqMCgGA1UEAxMhWmVyb1NTTCBF\nQ0MgRG9tYWluIFNlY3VyZSBTaXRlIENBMB4XDTI1MDYwNTAwMDAwMFoXDTI1MDkw\nMzIzNTk1OVowFzEVMBMGA1UEAwwMKi54a2NkbngueHl6MFkwEwYHKoZIzj0CAQYI\nKoZIzj0DAQcDQgAE24vP+qkpMa4CEURLrTbcETlAtCGKR4K/8Fr2SVu/VttPUPhQ\nDEtI7esRjCBqx+jCIHQvOU/k5mqLQi67JPLGk6OCAoUwggKBMB8GA1UdIwQYMBaA\nFA9r5kvOOUeu9n6QHnnwMJGSyF+jMB0GA1UdDgQWBBSHcpIfINglcd5jfFFvIaJC\n3VO4bzAOBgNVHQ8BAf8EBAMCB4AwDAYDVR0TAQH/BAIwADAdBgNVHSUEFjAUBggr\nBgEFBQcDAQYIKwYBBQUHAwIwSQYDVR0gBEIwQDA0BgsrBgEEAbIxAQICTjAlMCMG\nCCsGAQUFBwIBFhdodHRwczovL3NlY3RpZ28uY29tL0NQUzAIBgZngQwBAgEwgYgG\nCCsGAQUFBwEBBHwwejBLBggrBgEFBQcwAoY/aHR0cDovL3plcm9zc2wuY3J0LnNl\nY3RpZ28uY29tL1plcm9TU0xFQ0NEb21haW5TZWN1cmVTaXRlQ0EuY3J0MCsGCCsG\nAQUFBzABhh9odHRwOi8vemVyb3NzbC5vY3NwLnNlY3RpZ28uY29tMIIBBQYKKwYB\nBAHWeQIEAgSB9gSB8wDxAHcA3dzKNJXX4RYF55Uy+sef+D0cUN/bADoUEnYKLKy7\nyCoAAAGXP+E+BwAABAMASDBGAiEAz9cpfch0ZyH5J63MYYVMNxJTi1UsgY7H0Trr\n39Li5DsCIQC8L0VrLC6G/dTVGOiINNV4BFgIjGTYau5SwlAYG2OmfAB2AA3h8jAr\n0w3BQGISCepVLvxHdHyx1+kw7w5CHrR+Tqo0AAABlz/hPekAAAQDAEcwRQIgbQXe\n4wPmAAFBMXd0i8+zKXXXpn1G2U3UqPimIi7g4TkCIQC6nQECETDF14kP0zcK1CAD\nlL/I4sM/r9pbtWvNPkdDWDAjBgNVHREEHDAaggwqLnhrY2RueC54eXqCCnhrY2Ru\neC54eXowCgYIKoZIzj0EAwMDZwAwZAIwVom+nXvAu6wp83AwpOAht7UfNAxjHzbe\n3+kCeveK5prNo2tGIKH2bGqtyA/XmoATAjBm05u9GR+1KdPkFpIYlSo3PFNmo3Sm\neEurg8J9ZbK5QfswOcOI0ftpYhi6APhau6Y=\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIDhTCCAwygAwIBAgIQI7dt48G7KxpRlh4I6rdk6DAKBggqhkjOPQQDAzCBiDEL\nMAkGA1UEBhMCVVMxEzARBgNVBAgTCk5ldyBKZXJzZXkxFDASBgNVBAcTC0plcnNl\neSBDaXR5MR4wHAYDVQQKExVUaGUgVVNFUlRSVVNUIE5ldHdvcmsxLjAsBgNVBAMT\nJVVTRVJUcnVzdCBFQ0MgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkwHhcNMjAwMTMw\nMDAwMDAwWhcNMzAwMTI5MjM1OTU5WjBLMQswCQYDVQQGEwJBVDEQMA4GA1UEChMH\nWmVyb1NTTDEqMCgGA1UEAxMhWmVyb1NTTCBFQ0MgRG9tYWluIFNlY3VyZSBTaXRl\nIENBMHYwEAYHKoZIzj0CAQYFK4EEACIDYgAENkFhFytTJe2qypTk1tpIV+9QuoRk\ngte7BRvWHwYk9qUznYzn8QtVaGOCMBBfjWXsqqivl8q1hs4wAYl03uNOXgFu7iZ7\nzFP6I6T3RB0+TR5fZqathfby47yOCZiAJI4go4IBdTCCAXEwHwYDVR0jBBgwFoAU\nOuEJhtTPGcKWdnRJdtzgNcZjY5owHQYDVR0OBBYEFA9r5kvOOUeu9n6QHnnwMJGS\nyF+jMA4GA1UdDwEB/wQEAwIBhjASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdJQQW\nMBQGCCsGAQUFBwMBBggrBgEFBQcDAjAiBgNVHSAEGzAZMA0GCysGAQQBsjEBAgJO\nMAgGBmeBDAECATBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLnVzZXJ0cnVz\ndC5jb20vVVNFUlRydXN0RUNDQ2VydGlmaWNhdGlvbkF1dGhvcml0eS5jcmwwdgYI\nKwYBBQUHAQEEajBoMD8GCCsGAQUFBzAChjNodHRwOi8vY3J0LnVzZXJ0cnVzdC5j\nb20vVVNFUlRydXN0RUNDQWRkVHJ1c3RDQS5jcnQwJQYIKwYBBQUHMAGGGWh0dHA6\nLy9vY3NwLnVzZXJ0cnVzdC5jb20wCgYIKoZIzj0EAwMDZwAwZAIwJHBUDwHJQN3I\nVNltVMrICMqYQ3TYP/TXqV9t8mG5cAomG2MwqIsxnL937Gewf6WIAjAlrauksO6N\nUuDdDXyd330druJcZJx0+H5j5cFOYBaGsKdeGW7sCMaR2PsDFKGllas=\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIID0zCCArugAwIBAgIQVmcdBOpPmUxvEIFHWdJ1lDANBgkqhkiG9w0BAQwFADB7\nMQswCQYDVQQGEwJHQjEbMBkGA1UECAwSR3JlYXRlciBNYW5jaGVzdGVyMRAwDgYD\nVQQHDAdTYWxmb3JkMRowGAYDVQQKDBFDb21vZG8gQ0EgTGltaXRlZDEhMB8GA1UE\nAwwYQUFBIENlcnRpZmljYXRlIFNlcnZpY2VzMB4XDTE5MDMxMjAwMDAwMFoXDTI4\nMTIzMTIzNTk1OVowgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5\nMRQwEgYDVQQHEwtKZXJzZXkgQ2l0eTEeMBwGA1UEChMVVGhlIFVTRVJUUlVTVCBO\nZXR3b3JrMS4wLAYDVQQDEyVVU0VSVHJ1c3QgRUNDIENlcnRpZmljYXRpb24gQXV0\naG9yaXR5MHYwEAYHKoZIzj0CAQYFK4EEACIDYgAEGqxUWqn5aCPnetUkb1PGWthL\nq8bVttHmc3Gu3ZzWDGH926CJA7gFFOxXzu5dP+Ihs8731Ip54KODfi2X0GHE8Znc\nJZFjq38wo7Rw4sehM5zzvy5cU7Ffs30yf4o043l5o4HyMIHvMB8GA1UdIwQYMBaA\nFKARCiM+lvEH7OKvKe+CpX/QMKS0MB0GA1UdDgQWBBQ64QmG1M8ZwpZ2dEl23OA1\nxmNjmjAOBgNVHQ8BAf8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zARBgNVHSAECjAI\nMAYGBFUdIAAwQwYDVR0fBDwwOjA4oDagNIYyaHR0cDovL2NybC5jb21vZG9jYS5j\nb20vQUFBQ2VydGlmaWNhdGVTZXJ2aWNlcy5jcmwwNAYIKwYBBQUHAQEEKDAmMCQG\nCCsGAQUFBzABhhhodHRwOi8vb2NzcC5jb21vZG9jYS5jb20wDQYJKoZIhvcNAQEM\nBQADggEBABns652JLCALBIAdGN5CmXKZFjK9Dpx1WywV4ilAbe7/ctvbq5AfjJXy\nij0IckKJUAfiORVsAYfZFhr1wHUrxeZWEQff2Ji8fJ8ZOd+LygBkc7xGEJuTI42+\nFsMuCIKchjN0djsoTI0DQoWz4rIjQtUfenVqGtF8qmchxDM6OW1TyaLtYiKou+JV\nbJlsQ2uRl9EMC5MCHdK8aXdJ5htN978UeAOwproLtOGFfy/cQjutdAFI3tZs4RmY\nCV4Ks2dH/hzg1cEo70qLRDEmBDeNiXQ2Lu+lIg+DdEmSx/cQwgwp+7e9un/jX9Wf\n8qn0dNW44bOwgeThpWOjzOoEeJBuv/c=\n-----END CERTIFICATE-----\n','-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIEQ4dO6u2dHN5AVNppKoFp+aL61fuVLgw8XbkRALjuNOoAoGCCqGSM49\nAwEHoUQDQgAE24vP+qkpMa4CEURLrTbcETlAtCGKR4K/8Fr2SVu/VttPUPhQDEtI\n7esRjCBqx+jCIHQvOU/k5mqLQi67JPLGkw==\n-----END EC PRIVATE KEY-----\n'),(11,11,'ECC','256','2025-06-05 19:38:26','2025-06-05 19:43:42','c3e5405782b7aec290dab356e331cb64','2025-06-05 08:00:00','2025-09-04 07:59:59','ZeroSSL ECC Domain Secure Site CA',3,NULL,0,0,0,NULL,0,'2025-06-05 19:42:01',1,'{\"status\":\"pending\",\"expires\":\"2025-09-03T11:38:37Z\",\"identifiers\":[{\"type\":\"dns\",\"value\":\"1.xkcdnx.xyz\"}],\"authorizations\":[\"https:\\/\\/acme.zerossl.com\\/v2\\/DV90\\/authz\\/zTreqwzZmsMWf9FECQVWgA\"],\"finalize\":\"https:\\/\\/acme.zerossl.com\\/v2\\/DV90\\/order\\/gZY8mZ9b8hauixfypbc4kw\\/finalize\",\"location\":\"https:\\/\\/acme.zerossl.com\\/v2\\/DV90\\/order\\/gZY8mZ9b8hauixfypbc4kw\",\"challenges\":[{\"domain\":\"1.xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/acme.zerossl.com\\/v2\\/DV90\\/authz\\/zTreqwzZmsMWf9FECQVWgA\",\"challenge_url\":\"https:\\/\\/acme.zerossl.com\\/v2\\/DV90\\/chall\\/MZwk02FmeSCcw-eOiIBOXw\",\"key\":\"_acme-challenge.1.xkcdnx.xyz\",\"value\":\"n1-qPn9yBdN28s4BY_7be0hOr192atWMOwxQXQT80lk\"}]}','{\"xkcdnx.xyz\":[{\"name\":\"_acme-challenge.1\",\"type\":\"TXT\",\"value\":\"n1-qPn9yBdN28s4BY_7be0hOr192atWMOwxQXQT80lk\"}]}','-----BEGIN CERTIFICATE-----\nMIID+zCCA4CgAwIBAgIRANlatUpRIIHgYcSB9+LOzgcwCgYIKoZIzj0EAwMwSzEL\nMAkGA1UEBhMCQVQxEDAOBgNVBAoTB1plcm9TU0wxKjAoBgNVBAMTIVplcm9TU0wg\nRUNDIERvbWFpbiBTZWN1cmUgU2l0ZSBDQTAeFw0yNTA2MDUwMDAwMDBaFw0yNTA5\nMDMyMzU5NTlaMBcxFTATBgNVBAMTDDEueGtjZG54Lnh5ejBZMBMGByqGSM49AgEG\nCCqGSM49AwEHA0IABFwGBf1uKsn9FT8m9zQkxT6GsuIUJbxRM4ACKzbWufBU9xz6\nsgzMPG+oCt19glYvIW26rrU+4G22FnY6mQi4p66jggJ3MIICczAfBgNVHSMEGDAW\ngBQPa+ZLzjlHrvZ+kB558DCRkshfozAdBgNVHQ4EFgQUunGQDhY85YA/dj9cG/zT\nCAjLYNQwDgYDVR0PAQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwHQYDVR0lBBYwFAYI\nKwYBBQUHAwEGCCsGAQUFBwMCMEkGA1UdIARCMEAwNAYLKwYBBAGyMQECAk4wJTAj\nBggrBgEFBQcCARYXaHR0cHM6Ly9zZWN0aWdvLmNvbS9DUFMwCAYGZ4EMAQIBMIGI\nBggrBgEFBQcBAQR8MHowSwYIKwYBBQUHMAKGP2h0dHA6Ly96ZXJvc3NsLmNydC5z\nZWN0aWdvLmNvbS9aZXJvU1NMRUNDRG9tYWluU2VjdXJlU2l0ZUNBLmNydDArBggr\nBgEFBQcwAYYfaHR0cDovL3plcm9zc2wub2NzcC5zZWN0aWdvLmNvbTCCAQMGCisG\nAQQB1nkCBAIEgfQEgfEA7wB2AN3cyjSV1+EWBeeVMvrHn/g9HFDf2wA6FBJ2Ciys\nu8gqAAABlz/nLEoAAAQDAEcwRQIgSpa1p8q8+hy6H/S0jpTjYZggqCd1wPyshGFq\nIeW1Ma4CIQCErOYTFr2WdKMHTJTTbi8JqKQOGeMAzy0DsTnlFU+U4AB1AA3h8jAr\n0w3BQGISCepVLvxHdHyx1+kw7w5CHrR+Tqo0AAABlz/nK/4AAAQDAEYwRAIgayDl\nfC1VCo16eWjgvbRhCGDDClTQCVvUCQM5745+e9oCID/WmsSZbTKD14pOnzcMEZ7W\nhcAYz3AV5rOizdnkj292MBcGA1UdEQQQMA6CDDEueGtjZG54Lnh5ejAKBggqhkjO\nPQQDAwNpADBmAjEA/dARNYM4D3QXBLltLY7Tpv3RYa5nRDdlZ050SGa/p3vi7835\nHSiXgnWyTPIZVXueAjEAkQryfWvzihALQvR6mpMFqjHbJgIQJalS2kiZxsJbK7RT\nRCuh8G8u/zFzWjE1c2VH\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIDhTCCAwygAwIBAgIQI7dt48G7KxpRlh4I6rdk6DAKBggqhkjOPQQDAzCBiDEL\nMAkGA1UEBhMCVVMxEzARBgNVBAgTCk5ldyBKZXJzZXkxFDASBgNVBAcTC0plcnNl\neSBDaXR5MR4wHAYDVQQKExVUaGUgVVNFUlRSVVNUIE5ldHdvcmsxLjAsBgNVBAMT\nJVVTRVJUcnVzdCBFQ0MgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkwHhcNMjAwMTMw\nMDAwMDAwWhcNMzAwMTI5MjM1OTU5WjBLMQswCQYDVQQGEwJBVDEQMA4GA1UEChMH\nWmVyb1NTTDEqMCgGA1UEAxMhWmVyb1NTTCBFQ0MgRG9tYWluIFNlY3VyZSBTaXRl\nIENBMHYwEAYHKoZIzj0CAQYFK4EEACIDYgAENkFhFytTJe2qypTk1tpIV+9QuoRk\ngte7BRvWHwYk9qUznYzn8QtVaGOCMBBfjWXsqqivl8q1hs4wAYl03uNOXgFu7iZ7\nzFP6I6T3RB0+TR5fZqathfby47yOCZiAJI4go4IBdTCCAXEwHwYDVR0jBBgwFoAU\nOuEJhtTPGcKWdnRJdtzgNcZjY5owHQYDVR0OBBYEFA9r5kvOOUeu9n6QHnnwMJGS\nyF+jMA4GA1UdDwEB/wQEAwIBhjASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdJQQW\nMBQGCCsGAQUFBwMBBggrBgEFBQcDAjAiBgNVHSAEGzAZMA0GCysGAQQBsjEBAgJO\nMAgGBmeBDAECATBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLnVzZXJ0cnVz\ndC5jb20vVVNFUlRydXN0RUNDQ2VydGlmaWNhdGlvbkF1dGhvcml0eS5jcmwwdgYI\nKwYBBQUHAQEEajBoMD8GCCsGAQUFBzAChjNodHRwOi8vY3J0LnVzZXJ0cnVzdC5j\nb20vVVNFUlRydXN0RUNDQWRkVHJ1c3RDQS5jcnQwJQYIKwYBBQUHMAGGGWh0dHA6\nLy9vY3NwLnVzZXJ0cnVzdC5jb20wCgYIKoZIzj0EAwMDZwAwZAIwJHBUDwHJQN3I\nVNltVMrICMqYQ3TYP/TXqV9t8mG5cAomG2MwqIsxnL937Gewf6WIAjAlrauksO6N\nUuDdDXyd330druJcZJx0+H5j5cFOYBaGsKdeGW7sCMaR2PsDFKGllas=\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIID0zCCArugAwIBAgIQVmcdBOpPmUxvEIFHWdJ1lDANBgkqhkiG9w0BAQwFADB7\nMQswCQYDVQQGEwJHQjEbMBkGA1UECAwSR3JlYXRlciBNYW5jaGVzdGVyMRAwDgYD\nVQQHDAdTYWxmb3JkMRowGAYDVQQKDBFDb21vZG8gQ0EgTGltaXRlZDEhMB8GA1UE\nAwwYQUFBIENlcnRpZmljYXRlIFNlcnZpY2VzMB4XDTE5MDMxMjAwMDAwMFoXDTI4\nMTIzMTIzNTk1OVowgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpOZXcgSmVyc2V5\nMRQwEgYDVQQHEwtKZXJzZXkgQ2l0eTEeMBwGA1UEChMVVGhlIFVTRVJUUlVTVCBO\nZXR3b3JrMS4wLAYDVQQDEyVVU0VSVHJ1c3QgRUNDIENlcnRpZmljYXRpb24gQXV0\naG9yaXR5MHYwEAYHKoZIzj0CAQYFK4EEACIDYgAEGqxUWqn5aCPnetUkb1PGWthL\nq8bVttHmc3Gu3ZzWDGH926CJA7gFFOxXzu5dP+Ihs8731Ip54KODfi2X0GHE8Znc\nJZFjq38wo7Rw4sehM5zzvy5cU7Ffs30yf4o043l5o4HyMIHvMB8GA1UdIwQYMBaA\nFKARCiM+lvEH7OKvKe+CpX/QMKS0MB0GA1UdDgQWBBQ64QmG1M8ZwpZ2dEl23OA1\nxmNjmjAOBgNVHQ8BAf8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zARBgNVHSAECjAI\nMAYGBFUdIAAwQwYDVR0fBDwwOjA4oDagNIYyaHR0cDovL2NybC5jb21vZG9jYS5j\nb20vQUFBQ2VydGlmaWNhdGVTZXJ2aWNlcy5jcmwwNAYIKwYBBQUHAQEEKDAmMCQG\nCCsGAQUFBzABhhhodHRwOi8vb2NzcC5jb21vZG9jYS5jb20wDQYJKoZIhvcNAQEM\nBQADggEBABns652JLCALBIAdGN5CmXKZFjK9Dpx1WywV4ilAbe7/ctvbq5AfjJXy\nij0IckKJUAfiORVsAYfZFhr1wHUrxeZWEQff2Ji8fJ8ZOd+LygBkc7xGEJuTI42+\nFsMuCIKchjN0djsoTI0DQoWz4rIjQtUfenVqGtF8qmchxDM6OW1TyaLtYiKou+JV\nbJlsQ2uRl9EMC5MCHdK8aXdJ5htN978UeAOwproLtOGFfy/cQjutdAFI3tZs4RmY\nCV4Ks2dH/hzg1cEo70qLRDEmBDeNiXQ2Lu+lIg+DdEmSx/cQwgwp+7e9un/jX9Wf\n8qn0dNW44bOwgeThpWOjzOoEeJBuv/c=\n-----END CERTIFICATE-----\n','-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIDgV8q4bO/J13NqdB9ykD+bmWBKp9QXzzE8Ic0HnUIs/oAoGCCqGSM49\nAwEHoUQDQgAEXAYF/W4qyf0VPyb3NCTFPoay4hQlvFEzgAIrNta58FT3HPqyDMw8\nb6gK3X2CVi8hbbqutT7gbbYWdjqZCLinrg==\n-----END EC PRIVATE KEY-----\n'),(12,6,'ECC','256','2025-06-07 06:31:43','2025-06-07 06:33:37','7c4a517214c239fc31492562ea2564c0','2025-06-07 05:33:34','2025-09-05 05:33:33','WR1',3,NULL,0,0,0,NULL,0,'2025-06-07 06:33:23',0,'{\"status\":\"pending\",\"expires\":\"2025-07-04T22:31:53.19179702Z\",\"identifiers\":[{\"type\":\"dns\",\"value\":\"*.xkcdnx.xyz\"}],\"notBefore\":\"1970-01-01T00:00:00Z\",\"notAfter\":\"1970-01-01T00:00:00Z\",\"authorizations\":[\"https:\\/\\/123.9ts.cc\\/authz\\/Wxlgn1--GsNqO1u1WtyMNg\"],\"finalize\":\"https:\\/\\/123.9ts.cc\\/order\\/zu0aCEiQDkJCG6574KiVYw\\/finalize\",\"location\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/order\\/zu0aCEiQDkJCG6574KiVYw\",\"challenges\":[{\"domain\":\"*.xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/123.9ts.cc\\/authz\\/Wxlgn1--GsNqO1u1WtyMNg\",\"challenge_url\":\"https:\\/\\/123.9ts.cc\\/challenge\\/agKrAnU0nwYlyUQJED3QBQ\",\"key\":\"_acme-challenge.xkcdnx.xyz\",\"value\":\"Qcjr9V62_8GHOeuv5mEWqw4yztGw9ZyNXNMQxsQRz_4\"}]}','{\"xkcdnx.xyz\":[{\"name\":\"_acme-challenge\",\"type\":\"TXT\",\"value\":\"Qcjr9V62_8GHOeuv5mEWqw4yztGw9ZyNXNMQxsQRz_4\"}]}','-----BEGIN CERTIFICATE-----\nMIIEVzCCAz+gAwIBAgIQIuq7iUfou0kNU8DFb02vRTANBgkqhkiG9w0BAQsFADA7\nMQswCQYDVQQGEwJVUzEeMBwGA1UEChMVR29vZ2xlIFRydXN0IFNlcnZpY2VzMQww\nCgYDVQQDEwNXUjEwHhcNMjUwNjA2MjEzMzM0WhcNMjUwOTA0MjEzMzMzWjAXMRUw\nEwYDVQQDDAwqLnhrY2RueC54eXowWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAARp\n8RtWzxWME811pHX9ePL/kUQYo5kk1aszJLvz7CQr/4XPi6XeH/cKHEVoYPxq+Aj4\nSKYz5BqQyitHT/5ogotGo4ICRDCCAkAwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQM\nMAoGCCsGAQUFBwMBMAwGA1UdEwEB/wQCMAAwHQYDVR0OBBYEFPrPDzFPCjLSssp2\n916UMJCPGlzAMB8GA1UdIwQYMBaAFGZpSdTeKpyRA8+JDiS4DjADboguMF4GCCsG\nAQUFBwEBBFIwUDAnBggrBgEFBQcwAYYbaHR0cDovL28ucGtpLmdvb2cvcy93cjEv\nSXVvMCUGCCsGAQUFBzAChhlodHRwOi8vaS5wa2kuZ29vZy93cjEuY3J0MBcGA1Ud\nEQQQMA6CDCoueGtjZG54Lnh5ejATBgNVHSAEDDAKMAgGBmeBDAECATA2BgNVHR8E\nLzAtMCugKaAnhiVodHRwOi8vYy5wa2kuZ29vZy93cjEveXpXd3RzcVZGRm8uY3Js\nMIIBAwYKKwYBBAHWeQIEAgSB9ASB8QDvAHYAEvFONL1TckyEBhnDjz96E/jntWKH\niJxtMAWE6+WGJjoAAAGXR2DJUwAABAMARzBFAiEAsNN3WY9c94rj0JBYPvpDSLLw\nL8OxFraAihj49TZxMFoCIFW+hpMb4mtZRDsOg82B/Eao7G9ZSopaoCvIDLjoXtfp\nAHUAfVkeEuF4KnscYWd8Xv340IdcFKBOlZ65Ay/ZDowuebgAAAGXR2DJdwAABAMA\nRjBEAiBSAGXO9gPoFdmnWMMI/8CrAuUf6yKdZ85tfEw/fK0+wwIgFykmGvAtYqkv\njKQfK7+UbSZhgGF8w3wW39k1EGy3A+8wDQYJKoZIhvcNAQELBQADggEBABcTsBKh\nu64dMgnbMQPf6USCjxOfIwE2Da8qptyTlGGaiODpoJNOokToxZ26ZhJE1yjOGSfJ\nYp6acPWNK91phCTZjNUj6I0Df7vsmlsiqRLFpK9BVo489KVT1cgU32LoN1XgIZ2t\n+p7ZI3DZMjCsucsFtoUQ6mdxDLHxIVYSC03NCyb9lk7apaa/+cmbUHLY0Am2yoCC\nnS23QhFtbYwsLyOhOEThHZfRpigxJ5d3/YGUPZ+LkU+f7UHCpQWrU0jZZ8TYNoGJ\nXqxOpQbPR45s98cwHwoEh2UJkjo1mEbNzhlAu5laFPPy0NkceVasvItMxh+Hu0+P\nu7oS3zHRq/Xyjj0=\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIFCzCCAvOgAwIBAgIQf9niwtIEigR0tieibQhopzANBgkqhkiG9w0BAQsFADBH\nMQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExM\nQzEUMBIGA1UEAxMLR1RTIFJvb3QgUjEwHhcNMjMxMjEzMDkwMDAwWhcNMjkwMjIw\nMTQwMDAwWjA7MQswCQYDVQQGEwJVUzEeMBwGA1UEChMVR29vZ2xlIFRydXN0IFNl\ncnZpY2VzMQwwCgYDVQQDEwNXUjEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK\nAoIBAQDPbjYWircr7kaYAx1TcA937qNLoHK+jyMtwkfGj1yN+T3mGo7uMyINyRFI\nuLBizvRpDXICfd7VJg/DbpvPfg7XIM/GkDujggbaOp3/bFa/3OlhlEXkabxPD8kT\nwK1hRHIggdAPK55oamJqj4oiV3lpK+IkM352YyxdvFFpfiMHsf92gfHuuFi1azUV\n76HmSCg5lzHZBx+Vp56uz5i8no2KA+Gwl01Qb5NMSh/4233xkJkVf+OW7e4xgepy\nPVId3yVkpQtwqp7oqLlHyKdaECVgb0Lh1z/njwzwwoNGMyDmS3cEdqFop10VGO/Y\nKHc1rQ6tRuRibuKq+MzvN34PJrMHAgMBAAGjgf4wgfswDgYDVR0PAQH/BAQDAgGG\nMB0GA1UdJQQWMBQGCCsGAQUFBwMBBggrBgEFBQcDAjASBgNVHRMBAf8ECDAGAQH/\nAgEAMB0GA1UdDgQWBBRmaUnU3iqckQPPiQ4kuA4wA26ILjAfBgNVHSMEGDAWgBTk\nrysmcRorSCeFL1JmLO/wiRNxPjA0BggrBgEFBQcBAQQoMCYwJAYIKwYBBQUHMAKG\nGGh0dHA6Ly9pLnBraS5nb29nL3IxLmNydDArBgNVHR8EJDAiMCCgHqAchhpodHRw\nOi8vYy5wa2kuZ29vZy9yL3IxLmNybDATBgNVHSAEDDAKMAgGBmeBDAECATANBgkq\nhkiG9w0BAQsFAAOCAgEATuazCBEgkWAn+VGQTQIY7rjBidUihJfm1t/mTjo7KQR+\n3iDx4o2L06oeF0Q3wpKYpQgI/TeMqUlYMWQmZbWPE0PX8pfsVAE5E5tVOjh34bNA\nJwDPVnsZVJwzN3nw5BGQ7sxRspFzIcM/qbbTpNeXf9II4Wsk2+Tv6FSVFZUL3/0u\nHradbruDWjRQ4IZ7mYqKiEqk08dpOZ+TmBzwykEGy1/IXberb6Ap1SSnn2+RI7t6\nN/fqPCrwwFjp8kg1G6etRATGBaPYCx+GjJMFPX+k97Alvoj3/98SvqdegLPYEPjv\nxUclHpiKLD63NMmVarVQddIL6kOvTe5k0pnxRnR+mndGHIQc77TLbcZFeja56Pyn\nlSqmer578c7CBrPqo1BVmPyWUK+v6sGuzs7Mq7QQaxVs4710cI/MpPp1ovxMVt17\nENKxLk34LpEKAKVmqwnzbHHRjhXNeCC984XDOwLEp0K4MzHl8ZOWJQAakCdVlFC+\nPyA3GP2JX/QLoqWNHGuN9c9vLObDhHVs/L+65De+OdnnjpFGI9xxtsNyRsyaHdFA\nf5z7ulOoXDXkHCCej/Ehs5docReNt16W2xbH/EBuirJrOzFE2rtALxksl1TdEjOf\nIKXOJfUqQeVI5+hA7V+n1+A/n7Npg0S+5ODytWh5XW54ccN1drJnMK54ttozh0c=\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIFYjCCBEqgAwIBAgIQd70NbNs2+RrqIQ/E8FjTDTANBgkqhkiG9w0BAQsFADBX\nMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTEQMA4GA1UE\nCxMHUm9vdCBDQTEbMBkGA1UEAxMSR2xvYmFsU2lnbiBSb290IENBMB4XDTIwMDYx\nOTAwMDA0MloXDTI4MDEyODAwMDA0MlowRzELMAkGA1UEBhMCVVMxIjAgBgNVBAoT\nGUdvb2dsZSBUcnVzdCBTZXJ2aWNlcyBMTEMxFDASBgNVBAMTC0dUUyBSb290IFIx\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAthECix7joXebO9y/lD63\nladAPKH9gvl9MgaCcfb2jH/76Nu8ai6Xl6OMS/kr9rH5zoQdsfnFl97vufKj6bwS\niV6nqlKr+CMny6SxnGPb15l+8Ape62im9MZaRw1NEDPjTrETo8gYbEvs/AmQ351k\nKSUjB6G00j0uYODP0gmHu81I8E3CwnqIiru6z1kZ1q+PsAewnjHxgsHA3y6mbWwZ\nDrXYfiYaRQM9sHmklCitD38m5agI/pboPGiUU+6DOogrFZYJsuB6jC511pzrp1Zk\nj5ZPaK49l8KEj8C8QMALXL32h7M1bKwYUH+E4EzNktMg6TO8UpmvMrUpsyUqtEj5\ncuHKZPfmghCN6J3Cioj6OGaK/GP5Afl4/Xtcd/p2h/rs37EOeZVXtL0m79YB0esW\nCruOC7XFxYpVq9Os6pFLKcwZpDIlTirxZUTQAs6qzkm06p98g7BAe+dDq6dso499\niYH6TKX/1Y7DzkvgtdizjkXPdsDtQCv9Uw+wp9U7DbGKogPeMa3Md+pvez7W35Ei\nEua++tgy/BBjFFFy3l3WFpO9KWgz7zpm7AeKJt8T11dleCfeXkkUAKIAf5qoIbap\nsZWwpbkNFhHax2xIPEDgfg1azVY80ZcFuctL7TlLnMQ/0lUTbiSw1nH69MG6zO0b\n9f6BQdgAmD06yK56mDcYBZUCAwEAAaOCATgwggE0MA4GA1UdDwEB/wQEAwIBhjAP\nBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTkrysmcRorSCeFL1JmLO/wiRNxPjAf\nBgNVHSMEGDAWgBRge2YaRQ2XyolQL30EzTSo//z9SzBgBggrBgEFBQcBAQRUMFIw\nJQYIKwYBBQUHMAGGGWh0dHA6Ly9vY3NwLnBraS5nb29nL2dzcjEwKQYIKwYBBQUH\nMAKGHWh0dHA6Ly9wa2kuZ29vZy9nc3IxL2dzcjEuY3J0MDIGA1UdHwQrMCkwJ6Al\noCOGIWh0dHA6Ly9jcmwucGtpLmdvb2cvZ3NyMS9nc3IxLmNybDA7BgNVHSAENDAy\nMAgGBmeBDAECATAIBgZngQwBAgIwDQYLKwYBBAHWeQIFAwIwDQYLKwYBBAHWeQIF\nAwMwDQYJKoZIhvcNAQELBQADggEBADSkHrEoo9C0dhemMXoh6dFSPsjbdBZBiLg9\nNR3t5P+T4Vxfq7vqfM/b5A3Ri1fyJm9bvhdGaJQ3b2t6yMAYN/olUazsaL+yyEn9\nWprKASOshIArAoyZl+tJaox118fessmXn1hIVw41oeQa1v1vg4Fv74zPl6/AhSrw\n9U5pCZEt4Wi4wStz6dTZ/CLANx8LZh1J7QJVj2fhMtfTJr9w4z30Z209fOU0iOMy\n+qduBmpvvYuR7hZL6Dupszfnw0Skfths18dG9ZKb59UhvmaSGZRVbNQpsg3BZlvi\nd0lIKO2d1xozclOzgjXPYovJJIultzkMu34qQb9Sz/yilrbCgj8=\n-----END CERTIFICATE-----\n','-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIGxZWm1TogQTtb/dNeArsRpoVvAfUyhTXrhBSYwhBG9goAoGCCqGSM49\nAwEHoUQDQgAEafEbVs8VjBPNdaR1/Xjy/5FEGKOZJNWrMyS78+wkK/+Fz4ul3h/3\nChxFaGD8avgI+EimM+QakMorR0/+aIKLRg==\n-----END EC PRIVATE KEY-----\n'),(15,6,'ECC','256','2025-06-29 02:02:24','2025-06-29 02:35:50','7d39695a0cec2f475e055a856c6b8c44','2025-06-29 01:13:38','2025-09-27 01:13:37','WR1',4,NULL,0,0,0,NULL,0,'2025-06-29 02:13:13',0,'{\"status\":\"pending\",\"expires\":\"2025-07-04T22:33:30.800872554Z\",\"identifiers\":[{\"type\":\"dns\",\"value\":\"*.9ts.cc\"},{\"type\":\"dns\",\"value\":\"9ts.cc\"},{\"type\":\"dns\",\"value\":\"xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"*.xkcdnx.xyz\"}],\"notBefore\":\"1970-01-01T00:00:00Z\",\"notAfter\":\"1970-01-01T00:00:00Z\",\"authorizations\":[\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/Wxlgn1--GsNqO1u1WtyMNg\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/D2Rkw59CFVOJzGVP1yT1Wg\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/jExYquS27QACd-PMU9dmwQ\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/pgg4y-4U1YztXVVZzAuh7w\"],\"finalize\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/order\\/g19gD_n-14AYQUB7swhOxg\\/finalize\",\"location\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/order\\/g19gD_n-14AYQUB7swhOxg\",\"challenges\":[{\"domain\":\"*.9ts.cc\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/D2Rkw59CFVOJzGVP1yT1Wg\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/ZhLIYXSaquM8WQLwX0s24A\",\"key\":\"_acme-challenge.9ts.cc\",\"value\":\"sFkkgM5O6zDMb3-9Q0EGEdAioqqan3WWAHnzBFSJ09c\"},{\"domain\":\"xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/jExYquS27QACd-PMU9dmwQ\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/fCrpyn4izPwvx8D9X6SklQ\",\"key\":\"_acme-challenge.xkcdnx.xyz\",\"value\":\"bfNeIiiHIlBm1u1dsA1Wb3ItbhLW8yf4y4LsvS-FZoI\"},{\"domain\":\"9ts.cc\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/pgg4y-4U1YztXVVZzAuh7w\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/CRy5VZcI-ko8IbF1w5NU_g\",\"key\":\"_acme-challenge.9ts.cc\",\"value\":\"BmJNji9Qp_jtPf3r8_kqydBPubxyihjxVm5opskFfes\"}]}','{\"9ts.cc\":[{\"name\":\"_acme-challenge\",\"type\":\"TXT\",\"value\":\"sFkkgM5O6zDMb3-9Q0EGEdAioqqan3WWAHnzBFSJ09c\"},{\"name\":\"_acme-challenge\",\"type\":\"TXT\",\"value\":\"BmJNji9Qp_jtPf3r8_kqydBPubxyihjxVm5opskFfes\"}],\"xkcdnx.xyz\":[{\"name\":\"_acme-challenge\",\"type\":\"TXT\",\"value\":\"bfNeIiiHIlBm1u1dsA1Wb3ItbhLW8yf4y4LsvS-FZoI\"}]}','-----BEGIN CERTIFICATE-----\nMIIEdDCCA1ygAwIBAgIRAO9anH7PZBwEE5RsDkeB1QwwDQYJKoZIhvcNAQELBQAw\nOzELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFUdvb2dsZSBUcnVzdCBTZXJ2aWNlczEM\nMAoGA1UEAxMDV1IxMB4XDTI1MDYyODE3MTMzOFoXDTI1MDkyNjE3MTMzN1owEzER\nMA8GA1UEAwwIKi45dHMuY2MwWTATBgcqhkjOPQIBBggqhkjOPQMBBwNCAAQV/m/q\nXVWjVOPYXutgBblfVZzz5opMr7Kh+WgqqDwU8mAHAFrLsCaxnEiWGL9NyfHHBSZH\noAo+5BrLO7q7p5YHo4ICZDCCAmAwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoG\nCCsGAQUFBwMBMAwGA1UdEwEB/wQCMAAwHQYDVR0OBBYEFKT1Rkrhtb0fKXNlF9SY\nAs9qzKC1MB8GA1UdIwQYMBaAFGZpSdTeKpyRA8+JDiS4DjADboguMF4GCCsGAQUF\nBwEBBFIwUDAnBggrBgEFBQcwAYYbaHR0cDovL28ucGtpLmdvb2cvcy93cjEvNzFv\nMCUGCCsGAQUFBzAChhlodHRwOi8vaS5wa2kuZ29vZy93cjEuY3J0MDUGA1UdEQQu\nMCyCCCouOXRzLmNjggY5dHMuY2OCCnhrY2RueC54eXqCDCoueGtjZG54Lnh5ejAT\nBgNVHSAEDDAKMAgGBmeBDAECATA2BgNVHR8ELzAtMCugKaAnhiVodHRwOi8vYy5w\na2kuZ29vZy93cjEvTEVPZXE2M19JclkuY3JsMIIBBQYKKwYBBAHWeQIEAgSB9gSB\n8wDxAHcA3dzKNJXX4RYF55Uy+sef+D0cUN/bADoUEnYKLKy7yCoAAAGXt766PgAA\nBAMASDBGAiEA7b9fJFFR2wb/e3iRSkGaA9ufOET3TznUv2sLuagUyg4CIQDD9d5h\nefmN5WPig0fnyeC1TtwNvARnIfqUd9xnlLX5hwB2AA3h8jAr0w3BQGISCepVLvxH\ndHyx1+kw7w5CHrR+Tqo0AAABl7e+uhsAAAQDAEcwRQIhAN2lGLT5Brvlz/K4KbQh\nLsP+zIetQBBvLlkZ7tvX/85CAiB2oKn9NsiMk3Kww3rT0JamN6zqr6fNj+kiGVzZ\nzLHVpDANBgkqhkiG9w0BAQsFAAOCAQEAA5rzaBGQUfZmBk7vL6IAVzF5DXROcfl0\nBFxnKECFuoGq0s+07Ar+xTgWPm0YFbH2sKqCwJpQ/qzth2TqLBYGPZoia+oV5QdW\nC+D3rXj57gRbr98c0kKTZuIQcKg/IFUoHxse0j0fbXsd//dej2+75I33bU+VUrtM\nRX0EIRsOvrz5NvMPIqQNr0MY5KIZffA4AqfO1wKuvoPrwnC4vNIV34s6Uia+Dmkz\njBhZ6UescWIiou4QUYPSVXA/X+sHw+77uZRrvyeL1QDnEdL/3Hvc5sXas0Ur6mh/\nXAwpu50GJtw9w1PRJfNIhum4/Idty+4zkMO/DOb/AdrZcz+KJXfb6g==\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIFCzCCAvOgAwIBAgIQf9niwtIEigR0tieibQhopzANBgkqhkiG9w0BAQsFADBH\nMQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExM\nQzEUMBIGA1UEAxMLR1RTIFJvb3QgUjEwHhcNMjMxMjEzMDkwMDAwWhcNMjkwMjIw\nMTQwMDAwWjA7MQswCQYDVQQGEwJVUzEeMBwGA1UEChMVR29vZ2xlIFRydXN0IFNl\ncnZpY2VzMQwwCgYDVQQDEwNXUjEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK\nAoIBAQDPbjYWircr7kaYAx1TcA937qNLoHK+jyMtwkfGj1yN+T3mGo7uMyINyRFI\nuLBizvRpDXICfd7VJg/DbpvPfg7XIM/GkDujggbaOp3/bFa/3OlhlEXkabxPD8kT\nwK1hRHIggdAPK55oamJqj4oiV3lpK+IkM352YyxdvFFpfiMHsf92gfHuuFi1azUV\n76HmSCg5lzHZBx+Vp56uz5i8no2KA+Gwl01Qb5NMSh/4233xkJkVf+OW7e4xgepy\nPVId3yVkpQtwqp7oqLlHyKdaECVgb0Lh1z/njwzwwoNGMyDmS3cEdqFop10VGO/Y\nKHc1rQ6tRuRibuKq+MzvN34PJrMHAgMBAAGjgf4wgfswDgYDVR0PAQH/BAQDAgGG\nMB0GA1UdJQQWMBQGCCsGAQUFBwMBBggrBgEFBQcDAjASBgNVHRMBAf8ECDAGAQH/\nAgEAMB0GA1UdDgQWBBRmaUnU3iqckQPPiQ4kuA4wA26ILjAfBgNVHSMEGDAWgBTk\nrysmcRorSCeFL1JmLO/wiRNxPjA0BggrBgEFBQcBAQQoMCYwJAYIKwYBBQUHMAKG\nGGh0dHA6Ly9pLnBraS5nb29nL3IxLmNydDArBgNVHR8EJDAiMCCgHqAchhpodHRw\nOi8vYy5wa2kuZ29vZy9yL3IxLmNybDATBgNVHSAEDDAKMAgGBmeBDAECATANBgkq\nhkiG9w0BAQsFAAOCAgEATuazCBEgkWAn+VGQTQIY7rjBidUihJfm1t/mTjo7KQR+\n3iDx4o2L06oeF0Q3wpKYpQgI/TeMqUlYMWQmZbWPE0PX8pfsVAE5E5tVOjh34bNA\nJwDPVnsZVJwzN3nw5BGQ7sxRspFzIcM/qbbTpNeXf9II4Wsk2+Tv6FSVFZUL3/0u\nHradbruDWjRQ4IZ7mYqKiEqk08dpOZ+TmBzwykEGy1/IXberb6Ap1SSnn2+RI7t6\nN/fqPCrwwFjp8kg1G6etRATGBaPYCx+GjJMFPX+k97Alvoj3/98SvqdegLPYEPjv\nxUclHpiKLD63NMmVarVQddIL6kOvTe5k0pnxRnR+mndGHIQc77TLbcZFeja56Pyn\nlSqmer578c7CBrPqo1BVmPyWUK+v6sGuzs7Mq7QQaxVs4710cI/MpPp1ovxMVt17\nENKxLk34LpEKAKVmqwnzbHHRjhXNeCC984XDOwLEp0K4MzHl8ZOWJQAakCdVlFC+\nPyA3GP2JX/QLoqWNHGuN9c9vLObDhHVs/L+65De+OdnnjpFGI9xxtsNyRsyaHdFA\nf5z7ulOoXDXkHCCej/Ehs5docReNt16W2xbH/EBuirJrOzFE2rtALxksl1TdEjOf\nIKXOJfUqQeVI5+hA7V+n1+A/n7Npg0S+5ODytWh5XW54ccN1drJnMK54ttozh0c=\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIFYjCCBEqgAwIBAgIQd70NbNs2+RrqIQ/E8FjTDTANBgkqhkiG9w0BAQsFADBX\nMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTEQMA4GA1UE\nCxMHUm9vdCBDQTEbMBkGA1UEAxMSR2xvYmFsU2lnbiBSb290IENBMB4XDTIwMDYx\nOTAwMDA0MloXDTI4MDEyODAwMDA0MlowRzELMAkGA1UEBhMCVVMxIjAgBgNVBAoT\nGUdvb2dsZSBUcnVzdCBTZXJ2aWNlcyBMTEMxFDASBgNVBAMTC0dUUyBSb290IFIx\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAthECix7joXebO9y/lD63\nladAPKH9gvl9MgaCcfb2jH/76Nu8ai6Xl6OMS/kr9rH5zoQdsfnFl97vufKj6bwS\niV6nqlKr+CMny6SxnGPb15l+8Ape62im9MZaRw1NEDPjTrETo8gYbEvs/AmQ351k\nKSUjB6G00j0uYODP0gmHu81I8E3CwnqIiru6z1kZ1q+PsAewnjHxgsHA3y6mbWwZ\nDrXYfiYaRQM9sHmklCitD38m5agI/pboPGiUU+6DOogrFZYJsuB6jC511pzrp1Zk\nj5ZPaK49l8KEj8C8QMALXL32h7M1bKwYUH+E4EzNktMg6TO8UpmvMrUpsyUqtEj5\ncuHKZPfmghCN6J3Cioj6OGaK/GP5Afl4/Xtcd/p2h/rs37EOeZVXtL0m79YB0esW\nCruOC7XFxYpVq9Os6pFLKcwZpDIlTirxZUTQAs6qzkm06p98g7BAe+dDq6dso499\niYH6TKX/1Y7DzkvgtdizjkXPdsDtQCv9Uw+wp9U7DbGKogPeMa3Md+pvez7W35Ei\nEua++tgy/BBjFFFy3l3WFpO9KWgz7zpm7AeKJt8T11dleCfeXkkUAKIAf5qoIbap\nsZWwpbkNFhHax2xIPEDgfg1azVY80ZcFuctL7TlLnMQ/0lUTbiSw1nH69MG6zO0b\n9f6BQdgAmD06yK56mDcYBZUCAwEAAaOCATgwggE0MA4GA1UdDwEB/wQEAwIBhjAP\nBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTkrysmcRorSCeFL1JmLO/wiRNxPjAf\nBgNVHSMEGDAWgBRge2YaRQ2XyolQL30EzTSo//z9SzBgBggrBgEFBQcBAQRUMFIw\nJQYIKwYBBQUHMAGGGWh0dHA6Ly9vY3NwLnBraS5nb29nL2dzcjEwKQYIKwYBBQUH\nMAKGHWh0dHA6Ly9wa2kuZ29vZy9nc3IxL2dzcjEuY3J0MDIGA1UdHwQrMCkwJ6Al\noCOGIWh0dHA6Ly9jcmwucGtpLmdvb2cvZ3NyMS9nc3IxLmNybDA7BgNVHSAENDAy\nMAgGBmeBDAECATAIBgZngQwBAgIwDQYLKwYBBAHWeQIFAwIwDQYLKwYBBAHWeQIF\nAwMwDQYJKoZIhvcNAQELBQADggEBADSkHrEoo9C0dhemMXoh6dFSPsjbdBZBiLg9\nNR3t5P+T4Vxfq7vqfM/b5A3Ri1fyJm9bvhdGaJQ3b2t6yMAYN/olUazsaL+yyEn9\nWprKASOshIArAoyZl+tJaox118fessmXn1hIVw41oeQa1v1vg4Fv74zPl6/AhSrw\n9U5pCZEt4Wi4wStz6dTZ/CLANx8LZh1J7QJVj2fhMtfTJr9w4z30Z209fOU0iOMy\n+qduBmpvvYuR7hZL6Dupszfnw0Skfths18dG9ZKb59UhvmaSGZRVbNQpsg3BZlvi\nd0lIKO2d1xozclOzgjXPYovJJIultzkMu34qQb9Sz/yilrbCgj8=\n-----END CERTIFICATE-----\n','-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIICw2/mJ8AOF5EzoTxaexvLhxMaHwi8p4Wla+Muu3nEQoAoGCCqGSM49\nAwEHoUQDQgAEFf5v6l1Vo1Tj2F7rYAW5X1Wc8+aKTK+yofloKqg8FPJgBwBay7Am\nsZxIlhi/TcnxxwUmR6AKPuQayzu6u6eWBw==\n-----END EC PRIVATE KEY-----\n'),(16,6,'ECC','256','2025-06-29 02:38:30','2025-06-29 02:40:44','dd5aa5807c636a6eee8efdceab59d3ab','2025-06-29 01:40:37','2025-09-27 01:40:36','WR1',3,NULL,0,0,0,NULL,0,'2025-06-29 02:40:11',0,'{\"status\":\"pending\",\"expires\":\"2025-07-04T22:33:30.800872554Z\",\"identifiers\":[{\"type\":\"dns\",\"value\":\"*.xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"*.1.xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"*.2.xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"*.3.xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"*.4.xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"*.5.xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"*.6.xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"*.7.xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"*.8.xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"*.9.xkcdnx.xyz\"},{\"type\":\"dns\",\"value\":\"*.10.xkcdnx.xyz\"}],\"notBefore\":\"1970-01-01T00:00:00Z\",\"notAfter\":\"1970-01-01T00:00:00Z\",\"authorizations\":[\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/jExYquS27QACd-PMU9dmwQ\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/Wxlgn1--GsNqO1u1WtyMNg\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/40R83HybquI9uJmawpKd8w\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/ZZrST-_U2fJO2JHMmYHqzA\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/SxAWz1YJOr60UJEhPxP3kA\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/eMDwI_WnY6BIIzoq6k2Bpw\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/IBtvVevqbfwfngg2IOsMOQ\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/qSHOt5XjgW7xhi3xrWeUkg\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/Td5TSTHTH6XmV08uYrzrMA\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/TEl08tLbM221QE8bCTpeaQ\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/RkfzZT_jNCY68V3mFBH1Aw\",\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/HYrVJ1XzcR2JOt4J0QeGwQ\"],\"finalize\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/order\\/h2xr9hea_lGz-fLaH12v5w\\/finalize\",\"location\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/order\\/h2xr9hea_lGz-fLaH12v5w\",\"challenges\":[{\"domain\":\"*.9.xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/40R83HybquI9uJmawpKd8w\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/DyW8488TjGhDlhwWRTNr8A\",\"key\":\"_acme-challenge.9.xkcdnx.xyz\",\"value\":\"KL0E7trEkYlNWoAnlL0HK8jmZNDvSXa2QDn5VxeiIQ8\"},{\"domain\":\"*.7.xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/ZZrST-_U2fJO2JHMmYHqzA\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/OIedv_ZAlgdNh2E_HEqEnQ\",\"key\":\"_acme-challenge.7.xkcdnx.xyz\",\"value\":\"s0WUnqxmIcGV61u9cOYDdrmqFx_UDUGqJEhXweFWQ_Q\"},{\"domain\":\"*.8.xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/SxAWz1YJOr60UJEhPxP3kA\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/M9jnF-0W6fJ8aSO88hy5mQ\",\"key\":\"_acme-challenge.8.xkcdnx.xyz\",\"value\":\"Uub8OtNeZ4yTuFFv_nIA37iJt-eUREOXtVtYS28O8_U\"},{\"domain\":\"*.6.xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/eMDwI_WnY6BIIzoq6k2Bpw\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/2zi-u_Pmq0uJZcLpmP2T4w\",\"key\":\"_acme-challenge.6.xkcdnx.xyz\",\"value\":\"EqIuq7w_q8DE10yOqx7WRlWGOzHkeyTDpZpy_5xnb4E\"},{\"domain\":\"*.4.xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/IBtvVevqbfwfngg2IOsMOQ\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/lB_h43B4tWiMVkVPPLhFdQ\",\"key\":\"_acme-challenge.4.xkcdnx.xyz\",\"value\":\"WiGTGl-6Ic9Vy8GbWNH5lp4WJfb0VP59ZA3nj2-BccY\"},{\"domain\":\"*.5.xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/qSHOt5XjgW7xhi3xrWeUkg\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/Np4TcouIeek_atVvWmu-Xg\",\"key\":\"_acme-challenge.5.xkcdnx.xyz\",\"value\":\"hMonnadQGbqS15SNDCbXlToFsG1GDo7icJpGQJnD1UY\"},{\"domain\":\"*.3.xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/Td5TSTHTH6XmV08uYrzrMA\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/mbXHUSo55Ws8T9WLhAEOiw\",\"key\":\"_acme-challenge.3.xkcdnx.xyz\",\"value\":\"se5ZuT1h15BHqLEszKkw7p6hhKH_1l3SYkevtQ41Nqg\"},{\"domain\":\"*.1.xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/TEl08tLbM221QE8bCTpeaQ\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/4OYsVXC3w114HOCLLvR0uQ\",\"key\":\"_acme-challenge.1.xkcdnx.xyz\",\"value\":\"cvKDFeTEwxTsjP0j5A9o4JbxYKzwS3EI-aeRBrQifWM\"},{\"domain\":\"*.10.xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/RkfzZT_jNCY68V3mFBH1Aw\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/LiPJ7a91mjAURT0n9lRBwg\",\"key\":\"_acme-challenge.10.xkcdnx.xyz\",\"value\":\"aGy0X0CVqSQJs5TQiErYpgDbYMWinU2M8bh543TKFR8\"},{\"domain\":\"*.2.xkcdnx.xyz\",\"type\":\"dns-01\",\"auth_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/authz\\/HYrVJ1XzcR2JOt4J0QeGwQ\",\"challenge_url\":\"https:\\/\\/dv.acme-v02.api.pki.goog\\/challenge\\/GTT-HzolfevZhUi4-K8KcA\",\"key\":\"_acme-challenge.2.xkcdnx.xyz\",\"value\":\"FMm9dGQMnA0ie0aVf3_U0bglC7kDqJXTTJCLqlUsHqQ\"}]}','{\"xkcdnx.xyz\":[{\"name\":\"_acme-challenge.9\",\"type\":\"TXT\",\"value\":\"KL0E7trEkYlNWoAnlL0HK8jmZNDvSXa2QDn5VxeiIQ8\"},{\"name\":\"_acme-challenge.7\",\"type\":\"TXT\",\"value\":\"s0WUnqxmIcGV61u9cOYDdrmqFx_UDUGqJEhXweFWQ_Q\"},{\"name\":\"_acme-challenge.8\",\"type\":\"TXT\",\"value\":\"Uub8OtNeZ4yTuFFv_nIA37iJt-eUREOXtVtYS28O8_U\"},{\"name\":\"_acme-challenge.6\",\"type\":\"TXT\",\"value\":\"EqIuq7w_q8DE10yOqx7WRlWGOzHkeyTDpZpy_5xnb4E\"},{\"name\":\"_acme-challenge.4\",\"type\":\"TXT\",\"value\":\"WiGTGl-6Ic9Vy8GbWNH5lp4WJfb0VP59ZA3nj2-BccY\"},{\"name\":\"_acme-challenge.5\",\"type\":\"TXT\",\"value\":\"hMonnadQGbqS15SNDCbXlToFsG1GDo7icJpGQJnD1UY\"},{\"name\":\"_acme-challenge.3\",\"type\":\"TXT\",\"value\":\"se5ZuT1h15BHqLEszKkw7p6hhKH_1l3SYkevtQ41Nqg\"},{\"name\":\"_acme-challenge.1\",\"type\":\"TXT\",\"value\":\"cvKDFeTEwxTsjP0j5A9o4JbxYKzwS3EI-aeRBrQifWM\"},{\"name\":\"_acme-challenge.10\",\"type\":\"TXT\",\"value\":\"aGy0X0CVqSQJs5TQiErYpgDbYMWinU2M8bh543TKFR8\"},{\"name\":\"_acme-challenge.2\",\"type\":\"TXT\",\"value\":\"FMm9dGQMnA0ie0aVf3_U0bglC7kDqJXTTJCLqlUsHqQ\"}]}','-----BEGIN CERTIFICATE-----\nMIIFCTCCA/GgAwIBAgIRANFnrziYwGj5DYEC8XDBbSswDQYJKoZIhvcNAQELBQAw\nOzELMAkGA1UEBhMCVVMxHjAcBgNVBAoTFUdvb2dsZSBUcnVzdCBTZXJ2aWNlczEM\nMAoGA1UEAxMDV1IxMB4XDTI1MDYyODE3NDAzN1oXDTI1MDkyNjE3NDAzNlowFzEV\nMBMGA1UEAwwMKi54a2NkbngueHl6MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE\nzRpg42XOokh8NUV8Wqn9sc19WeETatyCYOaPhpJUai7WjqRcvPL8A+FuCGlTJchY\n1ns+/GwPq0w7+Ps9d5Mas6OCAvUwggLxMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUE\nDDAKBggrBgEFBQcDATAMBgNVHRMBAf8EAjAAMB0GA1UdDgQWBBTrJmmx7AqSeS5d\nwTW3pF1sv4QzrjAfBgNVHSMEGDAWgBRmaUnU3iqckQPPiQ4kuA4wA26ILjBeBggr\nBgEFBQcBAQRSMFAwJwYIKwYBBQUHMAGGG2h0dHA6Ly9vLnBraS5nb29nL3Mvd3Ix\nLzBXYzAlBggrBgEFBQcwAoYZaHR0cDovL2kucGtpLmdvb2cvd3IxLmNydDCBxgYD\nVR0RBIG+MIG7ggwqLnhrY2RueC54eXqCDiouMS54a2NkbngueHl6gg4qLjIueGtj\nZG54Lnh5eoIKeGtjZG54Lnh5eoIOKi4zLnhrY2RueC54eXqCDiouNC54a2Nkbngu\neHl6gg4qLjUueGtjZG54Lnh5eoIOKi42LnhrY2RueC54eXqCDiouNy54a2Nkbngu\neHl6gg4qLjgueGtjZG54Lnh5eoIOKi45LnhrY2RueC54eXqCDyouMTAueGtjZG54\nLnh5ejATBgNVHSAEDDAKMAgGBmeBDAECATA2BgNVHR8ELzAtMCugKaAnhiVodHRw\nOi8vYy5wa2kuZ29vZy93cjEvVGp2NlQzeEVodVEuY3JsMIIBBAYKKwYBBAHWeQIE\nAgSB9QSB8gDwAHYAEvFONL1TckyEBhnDjz96E/jntWKHiJxtMAWE6+WGJjoAAAGX\nt9dvmQAABAMARzBFAiArP7bbeLq5+UZttgLztgkdyPGZJxTq4VKYvAQhLgHkZgIh\nAP2co7mrvLfoVeroCQq5wPju4SyUn5B2PhiK+jpBLvjyAHYAGgT/SdBUHUCv9qDD\nv/HYxGcvTuzuI0BomGsXQC7ciX0AAAGXt9dv5AAABAMARzBFAiBPr9ijY3WV/DCu\niT7r4iSJAPRYKa9ZddV3oVK19oKKQgIhAKyrrHMiiOQ1Gn6Stjqv+iyLOUBG0mbo\nunKuvVhp90GHMA0GCSqGSIb3DQEBCwUAA4IBAQAIva4fZ7JH9+8NSKsEMSec6aQ3\ngP6wOas+je6FXASMGxZTD0++7MoXwGli6aENQIKCb4AgW27Etf09ERHJZP+pHjl3\ns+/9uJJsqwwGHoVgF25mT/hby5lY4gtWdUlmddoQFB1zbAZM7W/sfVFkKyMduX+v\n4xqtU1EIusbt7n+5yDgVm3DO7LvOwSLeQ+YmYwp1E6DuWhB0OJaq/xvGg6lJsPH4\nxnrT2l4rS2pcWV9BWV54aAdtbgZi8yV6p57tLsRcgZdVx60e4wafw/VyPP77aGFi\nVA6Bcu0UCA2ZOim4iBC1yn4ff9vF6c9BJbImpupswIYe+dd6EUsQUDElN4BJ\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIFCzCCAvOgAwIBAgIQf9niwtIEigR0tieibQhopzANBgkqhkiG9w0BAQsFADBH\nMQswCQYDVQQGEwJVUzEiMCAGA1UEChMZR29vZ2xlIFRydXN0IFNlcnZpY2VzIExM\nQzEUMBIGA1UEAxMLR1RTIFJvb3QgUjEwHhcNMjMxMjEzMDkwMDAwWhcNMjkwMjIw\nMTQwMDAwWjA7MQswCQYDVQQGEwJVUzEeMBwGA1UEChMVR29vZ2xlIFRydXN0IFNl\ncnZpY2VzMQwwCgYDVQQDEwNXUjEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEK\nAoIBAQDPbjYWircr7kaYAx1TcA937qNLoHK+jyMtwkfGj1yN+T3mGo7uMyINyRFI\nuLBizvRpDXICfd7VJg/DbpvPfg7XIM/GkDujggbaOp3/bFa/3OlhlEXkabxPD8kT\nwK1hRHIggdAPK55oamJqj4oiV3lpK+IkM352YyxdvFFpfiMHsf92gfHuuFi1azUV\n76HmSCg5lzHZBx+Vp56uz5i8no2KA+Gwl01Qb5NMSh/4233xkJkVf+OW7e4xgepy\nPVId3yVkpQtwqp7oqLlHyKdaECVgb0Lh1z/njwzwwoNGMyDmS3cEdqFop10VGO/Y\nKHc1rQ6tRuRibuKq+MzvN34PJrMHAgMBAAGjgf4wgfswDgYDVR0PAQH/BAQDAgGG\nMB0GA1UdJQQWMBQGCCsGAQUFBwMBBggrBgEFBQcDAjASBgNVHRMBAf8ECDAGAQH/\nAgEAMB0GA1UdDgQWBBRmaUnU3iqckQPPiQ4kuA4wA26ILjAfBgNVHSMEGDAWgBTk\nrysmcRorSCeFL1JmLO/wiRNxPjA0BggrBgEFBQcBAQQoMCYwJAYIKwYBBQUHMAKG\nGGh0dHA6Ly9pLnBraS5nb29nL3IxLmNydDArBgNVHR8EJDAiMCCgHqAchhpodHRw\nOi8vYy5wa2kuZ29vZy9yL3IxLmNybDATBgNVHSAEDDAKMAgGBmeBDAECATANBgkq\nhkiG9w0BAQsFAAOCAgEATuazCBEgkWAn+VGQTQIY7rjBidUihJfm1t/mTjo7KQR+\n3iDx4o2L06oeF0Q3wpKYpQgI/TeMqUlYMWQmZbWPE0PX8pfsVAE5E5tVOjh34bNA\nJwDPVnsZVJwzN3nw5BGQ7sxRspFzIcM/qbbTpNeXf9II4Wsk2+Tv6FSVFZUL3/0u\nHradbruDWjRQ4IZ7mYqKiEqk08dpOZ+TmBzwykEGy1/IXberb6Ap1SSnn2+RI7t6\nN/fqPCrwwFjp8kg1G6etRATGBaPYCx+GjJMFPX+k97Alvoj3/98SvqdegLPYEPjv\nxUclHpiKLD63NMmVarVQddIL6kOvTe5k0pnxRnR+mndGHIQc77TLbcZFeja56Pyn\nlSqmer578c7CBrPqo1BVmPyWUK+v6sGuzs7Mq7QQaxVs4710cI/MpPp1ovxMVt17\nENKxLk34LpEKAKVmqwnzbHHRjhXNeCC984XDOwLEp0K4MzHl8ZOWJQAakCdVlFC+\nPyA3GP2JX/QLoqWNHGuN9c9vLObDhHVs/L+65De+OdnnjpFGI9xxtsNyRsyaHdFA\nf5z7ulOoXDXkHCCej/Ehs5docReNt16W2xbH/EBuirJrOzFE2rtALxksl1TdEjOf\nIKXOJfUqQeVI5+hA7V+n1+A/n7Npg0S+5ODytWh5XW54ccN1drJnMK54ttozh0c=\n-----END CERTIFICATE-----\n-----BEGIN CERTIFICATE-----\nMIIFYjCCBEqgAwIBAgIQd70NbNs2+RrqIQ/E8FjTDTANBgkqhkiG9w0BAQsFADBX\nMQswCQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTEQMA4GA1UE\nCxMHUm9vdCBDQTEbMBkGA1UEAxMSR2xvYmFsU2lnbiBSb290IENBMB4XDTIwMDYx\nOTAwMDA0MloXDTI4MDEyODAwMDA0MlowRzELMAkGA1UEBhMCVVMxIjAgBgNVBAoT\nGUdvb2dsZSBUcnVzdCBTZXJ2aWNlcyBMTEMxFDASBgNVBAMTC0dUUyBSb290IFIx\nMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAthECix7joXebO9y/lD63\nladAPKH9gvl9MgaCcfb2jH/76Nu8ai6Xl6OMS/kr9rH5zoQdsfnFl97vufKj6bwS\niV6nqlKr+CMny6SxnGPb15l+8Ape62im9MZaRw1NEDPjTrETo8gYbEvs/AmQ351k\nKSUjB6G00j0uYODP0gmHu81I8E3CwnqIiru6z1kZ1q+PsAewnjHxgsHA3y6mbWwZ\nDrXYfiYaRQM9sHmklCitD38m5agI/pboPGiUU+6DOogrFZYJsuB6jC511pzrp1Zk\nj5ZPaK49l8KEj8C8QMALXL32h7M1bKwYUH+E4EzNktMg6TO8UpmvMrUpsyUqtEj5\ncuHKZPfmghCN6J3Cioj6OGaK/GP5Afl4/Xtcd/p2h/rs37EOeZVXtL0m79YB0esW\nCruOC7XFxYpVq9Os6pFLKcwZpDIlTirxZUTQAs6qzkm06p98g7BAe+dDq6dso499\niYH6TKX/1Y7DzkvgtdizjkXPdsDtQCv9Uw+wp9U7DbGKogPeMa3Md+pvez7W35Ei\nEua++tgy/BBjFFFy3l3WFpO9KWgz7zpm7AeKJt8T11dleCfeXkkUAKIAf5qoIbap\nsZWwpbkNFhHax2xIPEDgfg1azVY80ZcFuctL7TlLnMQ/0lUTbiSw1nH69MG6zO0b\n9f6BQdgAmD06yK56mDcYBZUCAwEAAaOCATgwggE0MA4GA1UdDwEB/wQEAwIBhjAP\nBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTkrysmcRorSCeFL1JmLO/wiRNxPjAf\nBgNVHSMEGDAWgBRge2YaRQ2XyolQL30EzTSo//z9SzBgBggrBgEFBQcBAQRUMFIw\nJQYIKwYBBQUHMAGGGWh0dHA6Ly9vY3NwLnBraS5nb29nL2dzcjEwKQYIKwYBBQUH\nMAKGHWh0dHA6Ly9wa2kuZ29vZy9nc3IxL2dzcjEuY3J0MDIGA1UdHwQrMCkwJ6Al\noCOGIWh0dHA6Ly9jcmwucGtpLmdvb2cvZ3NyMS9nc3IxLmNybDA7BgNVHSAENDAy\nMAgGBmeBDAECATAIBgZngQwBAgIwDQYLKwYBBAHWeQIFAwIwDQYLKwYBBAHWeQIF\nAwMwDQYJKoZIhvcNAQELBQADggEBADSkHrEoo9C0dhemMXoh6dFSPsjbdBZBiLg9\nNR3t5P+T4Vxfq7vqfM/b5A3Ri1fyJm9bvhdGaJQ3b2t6yMAYN/olUazsaL+yyEn9\nWprKASOshIArAoyZl+tJaox118fessmXn1hIVw41oeQa1v1vg4Fv74zPl6/AhSrw\n9U5pCZEt4Wi4wStz6dTZ/CLANx8LZh1J7QJVj2fhMtfTJr9w4z30Z209fOU0iOMy\n+qduBmpvvYuR7hZL6Dupszfnw0Skfths18dG9ZKb59UhvmaSGZRVbNQpsg3BZlvi\nd0lIKO2d1xozclOzgjXPYovJJIultzkMu34qQb9Sz/yilrbCgj8=\n-----END CERTIFICATE-----\n','-----BEGIN EC PRIVATE KEY-----\nMHcCAQEEIEXclFigI9fDxqFIJFokiGt4KIRbDLV/fMRfYlfcF+GdoAoGCCqGSM49\nAwEHoUQDQgAEzRpg42XOokh8NUV8Wqn9sc19WeETatyCYOaPhpJUai7WjqRcvPL8\nA+FuCGlTJchY1ns+/GwPq0w7+Ps9d5Masw==\n-----END EC PRIVATE KEY-----\n');
/*!40000 ALTER TABLE `dnsmgr_cert_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_config`
--

DROP TABLE IF EXISTS `dnsmgr_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_config` (
  `key` varchar(32) NOT NULL,
  `value` text,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_config`
--

LOCK TABLES `dnsmgr_config` WRITE;
/*!40000 ALTER TABLE `dnsmgr_config` DISABLE KEYS */;
INSERT INTO `dnsmgr_config` VALUES ('certtask_time','2025-06-22 22:06:01'),('mail_port','465'),('mail_smtp','smtp.qq.com'),('notice_mail','0'),('notice_wxtpl','0'),('proxy_port','8081'),('proxy_pwd',''),('proxy_server','98.152.200.61'),('proxy_type','sock5'),('proxy_user',''),('run_count','0'),('run_error',''),('run_time','2025-05-13 00:09:29'),('sys_key','739297277Gd6TG0l'),('tgbot_chatid','-1087393863'),('tgbot_proxy','1'),('tgbot_token','8091764032:AAE6hsnubRkjtNDiOCEveK_vRzdy66pc-kM'),('tgbot_url',''),('version','1033');
/*!40000 ALTER TABLE `dnsmgr_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_dmlog`
--

DROP TABLE IF EXISTS `dnsmgr_dmlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_dmlog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `taskid` int(11) unsigned NOT NULL,
  `action` tinyint(4) NOT NULL DEFAULT '0',
  `errmsg` varchar(100) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taskid` (`taskid`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_dmlog`
--

LOCK TABLES `dnsmgr_dmlog` WRITE;
/*!40000 ALTER TABLE `dnsmgr_dmlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnsmgr_dmlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_dmtask`
--

DROP TABLE IF EXISTS `dnsmgr_dmtask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_dmtask` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `did` int(11) unsigned NOT NULL,
  `rr` varchar(128) NOT NULL,
  `recordid` varchar(60) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `main_value` varchar(128) DEFAULT NULL,
  `backup_value` varchar(128) DEFAULT NULL,
  `checktype` tinyint(1) NOT NULL DEFAULT '0',
  `checkurl` varchar(512) DEFAULT NULL,
  `tcpport` int(5) DEFAULT NULL,
  `frequency` tinyint(5) NOT NULL,
  `cycle` tinyint(5) NOT NULL DEFAULT '3',
  `timeout` tinyint(5) NOT NULL DEFAULT '2',
  `remark` varchar(100) DEFAULT NULL,
  `proxy` tinyint(1) NOT NULL DEFAULT '0',
  `cdn` tinyint(1) NOT NULL DEFAULT '0',
  `addtime` int(11) NOT NULL DEFAULT '0',
  `checktime` int(11) NOT NULL DEFAULT '0',
  `checknexttime` int(11) NOT NULL DEFAULT '0',
  `switchtime` int(11) NOT NULL DEFAULT '0',
  `errcount` tinyint(5) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `recordinfo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `did` (`did`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_dmtask`
--

LOCK TABLES `dnsmgr_dmtask` WRITE;
/*!40000 ALTER TABLE `dnsmgr_dmtask` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnsmgr_dmtask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_domain`
--

DROP TABLE IF EXISTS `dnsmgr_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_domain` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(11) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `thirdid` varchar(60) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `is_hide` tinyint(1) NOT NULL DEFAULT '0',
  `is_sso` tinyint(1) NOT NULL DEFAULT '0',
  `recordcount` int(1) NOT NULL DEFAULT '0',
  `remark` varchar(100) DEFAULT NULL,
  `is_notice` tinyint(1) NOT NULL DEFAULT '0',
  `regtime` datetime DEFAULT NULL,
  `expiretime` datetime DEFAULT NULL,
  `checktime` datetime DEFAULT NULL,
  `noticetime` datetime DEFAULT NULL,
  `checkstatus` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_domain`
--

LOCK TABLES `dnsmgr_domain` WRITE;
/*!40000 ALTER TABLE `dnsmgr_domain` DISABLE KEYS */;
INSERT INTO `dnsmgr_domain` VALUES (3,2,'xkcdnx.xyz','70a7e6d1ac6c884d9d9abd418dfcebb7','2025-03-13 05:22:43',0,1,8,NULL,0,'2025-03-11 17:57:44','2026-03-11 17:57:44','2025-06-05 13:40:04',NULL,1),(4,3,'xkcdn.xyz','96413671','2025-03-13 06:09:54',0,1,32,NULL,0,'2024-04-05 15:36:25','2025-04-06 07:59:59','2025-06-05 13:43:10',NULL,1),(6,2,'9ts.cc','d4ced1bc21c61eec968f568b36578257','2025-06-29 02:12:13',0,1,2,NULL,0,'2020-02-10 05:02:11','2026-02-10 05:02:11','2025-06-29 02:12:17',NULL,1);
/*!40000 ALTER TABLE `dnsmgr_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_log`
--

DROP TABLE IF EXISTS `dnsmgr_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `action` varchar(40) NOT NULL,
  `domain` varchar(128) NOT NULL DEFAULT '',
  `data` varchar(500) DEFAULT NULL,
  `addtime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `domain` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_log`
--

LOCK TABLES `dnsmgr_log` WRITE;
/*!40000 ALTER TABLE `dnsmgr_log` DISABLE KEYS */;
INSERT INTO `dnsmgr_log` VALUES (1,1000,'登录后台','','IP:112.96.229.170','2025-03-09 00:40:51'),(2,1000,'登录后台','','IP:156.246.94.237','2025-03-13 00:52:34'),(3,1000,'删除解析','xkcdn.xyz','cf [A] 104.19.191.45 (线路:10=0 TTL:1)','2025-03-13 06:33:15'),(4,1000,'删除解析','xkcdn.xyz','cf [A] 104.18.254.51 (线路:10=0 TTL:1)','2025-03-13 06:33:16'),(5,1000,'删除解析','xkcdn.xyz','cf [A] 104.18.174.40 (线路:10=0 TTL:1)','2025-03-13 06:33:17'),(6,1000,'删除解析','xkcdn.xyz','cf [A] 104.17.63.180 (线路:10=0 TTL:1)','2025-03-13 06:33:17'),(7,1000,'删除解析','xkcdn.xyz','cf [A] 172.64.34.61 (线路:10=0 TTL:1)','2025-03-13 06:33:18'),(8,1000,'删除解析','xkcdn.xyz','cf [A] 104.17.223.202 (线路:10=1 TTL:1)','2025-03-13 06:33:19'),(9,1000,'删除解析','xkcdn.xyz','cf [A] 104.18.142.253 (线路:10=1 TTL:1)','2025-03-13 06:33:19'),(10,1000,'删除解析','xkcdn.xyz','cf [A] 104.17.31.183 (线路:10=1 TTL:1)','2025-03-13 06:33:20'),(11,1000,'删除解析','xkcdn.xyz','cf [A] 104.16.174.23 (线路:10=1 TTL:1)','2025-03-13 06:33:20'),(12,1000,'删除解析','xkcdn.xyz','cf [A] 104.17.255.92 (线路:10=1 TTL:1)','2025-03-13 06:33:21'),(13,1000,'删除解析','xkcdn.xyz','cf [A] 104.18.31.61 (线路:10=3 TTL:1)','2025-03-13 06:33:22'),(14,1000,'删除解析','xkcdn.xyz','cf [A] 104.18.63.26 (线路:10=3 TTL:1)','2025-03-13 06:33:22'),(15,1000,'删除解析','xkcdn.xyz','cf [A] 104.18.13.250 (线路:10=3 TTL:1)','2025-03-13 06:33:23'),(16,1000,'删除解析','xkcdn.xyz','cf [A] 104.17.31.254 (线路:10=3 TTL:1)','2025-03-13 06:33:34'),(17,1000,'删除解析','xkcdn.xyz','cf [A] 104.16.62.188 (线路:10=3 TTL:1)','2025-03-13 06:33:35'),(18,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:90d9::6d57:571a (线路:10=0 TTL:1)','2025-03-13 06:33:36'),(19,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:3001::5213:4a5c (线路:10=0 TTL:1)','2025-03-13 06:33:36'),(20,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:8ca0::58a:7bc (线路:10=0 TTL:1)','2025-03-13 06:33:37'),(21,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:a0::30a3:64d5 (线路:10=0 TTL:1)','2025-03-13 06:33:37'),(22,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:8ca7::6351:21ad (线路:10=0 TTL:1)','2025-03-13 06:33:37'),(23,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:3006::c49:7b0c (线路:10=1 TTL:1)','2025-03-13 06:33:38'),(24,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:440a::2d74:3ab2 (线路:10=1 TTL:1)','2025-03-13 06:33:39'),(25,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:a8::39b8:3f6f (线路:10=1 TTL:1)','2025-03-13 06:33:40'),(26,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:440b::a69:1340 (线路:10=1 TTL:1)','2025-03-13 06:33:41'),(27,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:a8::120a:4fc4 (线路:10=1 TTL:1)','2025-03-13 06:33:41'),(28,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:3036::6a9d:259c (线路:10=3 TTL:1)','2025-03-13 06:33:42'),(29,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:3032::7388:2ae0 (线路:10=3 TTL:1)','2025-03-13 06:33:43'),(30,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:2e::197f:4f89 (线路:10=3 TTL:1)','2025-03-13 06:33:43'),(31,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:3031::249:1be3 (线路:10=3 TTL:1)','2025-03-13 06:33:44'),(32,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:3031::b12:479e (线路:10=3 TTL:1)','2025-03-13 06:33:45'),(33,1000,'删除解析','xkcdn.xyz','cf [A] 104.19.191.45 (线路:0 TTL:1)','2025-03-13 06:33:45'),(34,1000,'删除解析','xkcdn.xyz','cf [A] 104.18.254.51 (线路:0 TTL:1)','2025-03-13 06:33:46'),(35,1000,'删除解析','xkcdn.xyz','cf [A] 104.18.174.40 (线路:0 TTL:1)','2025-03-13 06:33:47'),(36,1000,'删除解析','xkcdn.xyz','cf [A] 104.17.63.180 (线路:0 TTL:1)','2025-03-13 06:33:48'),(37,1000,'删除解析','xkcdn.xyz','cf [A] 172.64.34.61 (线路:0 TTL:1)','2025-03-13 06:33:48'),(38,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:90d9::6d57:571a (线路:0 TTL:1)','2025-03-13 06:33:49'),(39,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:3001::5213:4a5c (线路:0 TTL:1)','2025-03-13 06:33:50'),(40,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:8ca0::58a:7bc (线路:0 TTL:1)','2025-03-13 06:33:50'),(41,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:a0::30a3:64d5 (线路:0 TTL:1)','2025-03-13 06:33:51'),(42,1000,'删除解析','xkcdn.xyz','cf [AAAA] 2606:4700:8ca7::6351:21ad (线路:0 TTL:1)','2025-03-13 06:33:52'),(43,1000,'添加解析','xkcdn.xyz','cf [A] 223.5.5.5 (线路:0 TTL:1)','2025-03-13 06:34:10'),(44,1000,'修改解析','xkcdn.xyz','cf [A] 223.5.5.5 → cf [A] 180.76.76.76 (线路:0 TTL:1)','2025-03-13 06:36:39'),(45,1000,'修改解析','xkcdn.xyz','cf [A] 180.76.76.76 → cf [A] 119.29.29.29 (线路:0 TTL:1)','2025-03-13 06:42:59'),(46,1000,'修改解析','xkcdn.xyz','cf [A] 119.29.29.29 → cf [A] 1.1.1.1 (线路:0 TTL:1)','2025-03-13 06:43:35'),(47,1000,'删除解析','xkcdn.xyz','cf [A] 1.1.1.1 (线路:0 TTL:1)','2025-03-13 06:44:40'),(48,1000,'登录后台','','IP:112.97.177.195','2025-04-22 23:45:08'),(49,0,'暂停解析失败','xkcdnx.xyz',NULL,'2025-04-22 23:48:06'),(50,1000,'登录后台','','IP:223.104.79.157','2025-05-22 16:25:58'),(51,1000,'登录后台','','IP:112.97.166.225','2025-06-26 21:21:08'),(52,1000,'添加解析','9ts.cc','_acme-challenge [TXT] BmJNji9Qp_jtPf3r8_kqydBPubxyihjxVm5opskFfes (线路:0 TTL:600)','2025-06-29 02:12:30'),(53,1000,'添加解析','9ts.cc','sFkkgM5O6zDMb3-9Q0EGEdAioqqan3WWAHnzBFSJ09c [TXT] sFkkgM5O6zDMb3-9Q0EGEdAioqqan3WWAHnzBFSJ09c (线路:0 TTL:600)','2025-06-29 02:12:41');
/*!40000 ALTER TABLE `dnsmgr_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_optimizeip`
--

DROP TABLE IF EXISTS `dnsmgr_optimizeip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_optimizeip` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `did` int(11) unsigned NOT NULL,
  `rr` varchar(128) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `ip_type` varchar(10) NOT NULL,
  `cdn_type` tinyint(5) NOT NULL DEFAULT '1',
  `recordnum` tinyint(5) NOT NULL DEFAULT '2',
  `ttl` int(5) NOT NULL DEFAULT '600',
  `remark` varchar(100) DEFAULT NULL,
  `addtime` datetime NOT NULL,
  `updatetime` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `errmsg` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `did` (`did`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_optimizeip`
--

LOCK TABLES `dnsmgr_optimizeip` WRITE;
/*!40000 ALTER TABLE `dnsmgr_optimizeip` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnsmgr_optimizeip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_permission`
--

DROP TABLE IF EXISTS `dnsmgr_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_permission` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `domain` varchar(128) NOT NULL,
  `sub` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_permission`
--

LOCK TABLES `dnsmgr_permission` WRITE;
/*!40000 ALTER TABLE `dnsmgr_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `dnsmgr_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dnsmgr_user`
--

DROP TABLE IF EXISTS `dnsmgr_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dnsmgr_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `password` varchar(80) NOT NULL,
  `is_api` tinyint(1) NOT NULL DEFAULT '0',
  `apikey` varchar(32) DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `regtime` datetime DEFAULT NULL,
  `lasttime` datetime DEFAULT NULL,
  `totp_open` tinyint(1) NOT NULL DEFAULT '0',
  `totp_secret` varchar(100) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dnsmgr_user`
--

LOCK TABLES `dnsmgr_user` WRITE;
/*!40000 ALTER TABLE `dnsmgr_user` DISABLE KEYS */;
INSERT INTO `dnsmgr_user` VALUES (1000,'admin','$2y$10$lCywl9sfcxvaUp.knRHWy.iQbfEiTz4.O.oV4MaUdwC0zMPDHqA6G',0,'tYwsddB8pwmeAtC7',2,'2025-03-09 00:40:27','2025-06-26 21:21:08',1,'5UBGCLCBT3ZXLSKATEHTQU3BX7XRAF4Q',1);
/*!40000 ALTER TABLE `dnsmgr_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database '1'
--

--
-- Dumping routines for database '1'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-29  2:46:30
